/* 	LED Panel with addressing
	Modification by Michael Reiser
		
	This is a modified version for the new (12/04) SMD version of the board
	made on 12/09/04 by MBR
*/

#include "Panel.h"
#include <avr/io.h>

volatile unsigned char CurrentCol;
unsigned char CurrentFrame;   //for GS frame

unsigned char DisplayBuffer[8];
unsigned char GS_Buffer[3][8];
unsigned char PATTERNS[RAM_PAT_NUMS][8];
unsigned char currentnum;
unsigned char deviceAddr;

//unsigned char Frame1_0;
//unsigned char Frame2_0;
//unsigned char Frame3_0;

//unsigned char same;
//unsigned char opp;

unsigned char Map_flag = 0;   // = 0; debug only!
unsigned char Gray_Scale = 0;
//unsigned char Zero_map = 0;
//unsigned char One_map = 1;
unsigned char start_up = 1;

	
void i2cSlaveReceiveService(u08 receiveDataLength, u08* receiveData);

int main(void)
{	
	deviceAddr = eeprom_read_byte(Panel_ID);
	
	outp(MASK_05, LED_DATA_PORT_DIRECTION_05);		/* set LED DATA, bits 0 - 5, to write mode */
	sbi(DDRC,PC0);
	sbi(DDRC,PC1);
	//outp(MASK_67, LED_DATA_PORT_DIRECTION_67);		/* set LED DATA, bits 6 - 7, to write mode */
		
	outp(DD_WRITE,LED_ADDRESS_PORT_DIRECTION);	/* set LED ADDRESS to write mode */
	sbi(DDRC,PC3);
	sbi(PORTC,PC3);
		
	//CurrentCol = 0;			/* init current column variable */
	CurrentCol = 7;			/* init current column variable */
	CurrentFrame = 0;
	Gray_Scale = 1;				
	
	Handler_Init();					/* setup handlers */
	Reg_Handler(UpdateDisplay,3,1);	//runs at about 1/(3*256*8*(1/16E6)) = 2.6 Khz, or 372 Hz worst case (div by 7)
	//Reg_Handler(UpdateDisplay,4,1);	//runs at about 1/(4*256*8*(1/16E6)) = 1.95 Khz
	//Reg_Handler(UpdateDisplay,2,1);	//runs at about 1/(2*256*8*(1/16E6)) = 3.9 Khz
	
	//Reg_Handler(UpdateDisplay,20,1);	//runs at about 1/(20*256*8*(1/16E6)) = 390 Hz
	
	DisplayNum();
	
	i2cInit(); 
	i2cSetBitrate(400);
 	i2cSetLocalDeviceAddr(deviceAddr << 1, TRUE);
	i2cSetSlaveReceiveHandler( i2cSlaveReceiveService );
	
	long_delay(400);
	start_up = 0;	
	
	//just for testing new mode
	/*long_delay(400);
	LoadPattern_1byte(0x00);
	long_delay(400);
	LoadPattern_1byte(0xF0);*/
	while(1) { }
	return 0;
}


void i2cSlaveReceiveService(u08 receiveDataLength, u08* receiveData)
{	
	u08 EEpat_num, frame_num;
		
	//use the length of the received packet to determine action
	switch(receiveDataLength) {
	case 1: // if length 1, then this is 1 byte - need to stretch to 8 bytes
		LoadPattern_1byte(*receiveData);
		break; 		
	case 2:   
	//a reset is 0x00, 0x01; display ID is: 0x00 0x02 Update ID is 0xFF, New Address
	// for first digit different than 0x00, first char is ID for pattern in eeprom - 0x10, 
	// and second char is pattern number.
	//note - for row compressed patterns, 2 byte patterns are not supported!
		switch(*receiveData) {
		case 0x00: 
			if (*(receiveData+1) == 0x01) SystemReset();
			else if (*(receiveData+1) == 0x02) DisplayNum();
			break;
		
		case 0xF0:
			// just load that pattern from PATTERNS
			LoadPattern(PATTERNS[*(receiveData+1)]);
			break; 
			
		case 0xFF:   //updates the address, checks for gencall
			if ( start_up && ( ( i2cGetGenCall() && ( deviceAddr == 0 ) ) || (i2cGetGenCall() == 0 ) ) ){ 
				deviceAddr = *(receiveData+1);
				eeprom_write_byte( Panel_ID, deviceAddr);
				i2cSetLocalDeviceAddr(deviceAddr << 1, TRUE);
				DisplayNum();
				}
			else {LoadPatternEEP(SYMBOLS[1]);}	//first dot means not addressed correctly to update
			break;
		default:
			EEpat_num = (*receiveData) - 0x10;
			frame_num = *(receiveData+1);
			
			if ( (EEpat_num < EEPAT_NUMS) & (frame_num < EEPAT_LENGTH[EEpat_num]) )			
				LoadPatternEEP(EEPATTERNS[EEPAT_START[EEpat_num]+frame_num]);
			else			
			LoadPatternEEP(SYMBOLS[2]);	//second dot means 'pattern referrenced to is invalid'
		}
		break;
	
	case 3: // if length 3, then this is a compressed g_scale pattern need to stretch to 24 bytes
		LoadPattern_3byte(receiveData);
		Gray_Scale = 7;     // this is a 7 level pattern - so Gray_Scale is 7
		break; 
		
	case 8: LoadPattern(receiveData);	//stream in pattern		
		//Gray_Scale = 1;  , This is now set in LoadPattern.
		break;	
	
	case 9:	StorePattern(*(receiveData+8), receiveData);	
		break;		
		
			
	case 16: LoadPattern16(receiveData);	//stream in pattern		
		Gray_Scale = 3;     // this is a 2 byte pattern - so Gray_Scale is 3
		break;	
		
	case 24: LoadPattern24(receiveData);	//stream in pattern		
		Gray_Scale = 7;     // this is a 7 level pattern - so Gray_Scale is 7
		break;	
		
	default:
		LoadPatternEEP(SYMBOLS[3]);   //third dot means wierd packet size received
		}
}


void UpdateDisplay(void)
{
	unsigned char temp_frame;
		
	outp(0x00,LED_DATA_PORT_05);
	outp(0x08,LED_DATA_PORT_67);   // need 0x08 to keep reset line disabled, this is PC3 - so 4th bit from end
	outp((1<<CurrentCol),LED_ADDRESS_PORT);

	if (Gray_Scale == 1){
		outp(MASK_05&DisplayBuffer[CurrentCol],LED_DATA_PORT_05);
		LED_DATA_PORT_67 |= (MASK_67&DisplayBuffer[CurrentCol])>>6;
	}   // need to do |= on this port to keep reset line disabled.
		
	else if (Gray_Scale == 3){
	
		switch(CurrentFrame) {
			case 0:
				temp_frame = GS_Buffer[0][CurrentCol]|GS_Buffer[1][CurrentCol];
				outp(MASK_05&temp_frame,LED_DATA_PORT_05);
				LED_DATA_PORT_67 |= (MASK_67&temp_frame)>>6;
				break;
			
			case 1:
				temp_frame = GS_Buffer[0][CurrentCol];
				outp(MASK_05&temp_frame,LED_DATA_PORT_05);
				LED_DATA_PORT_67 |= (MASK_67&temp_frame)>>6;
				break;
				
			case 2:
				temp_frame = (GS_Buffer[0][CurrentCol]&GS_Buffer[1][CurrentCol]);
				outp(MASK_05&temp_frame,LED_DATA_PORT_05);
				LED_DATA_PORT_67 |= (MASK_67&temp_frame)>>6;
				break;
				}
		}
	
	
	else {
		switch(CurrentFrame) {
				
			case 0:
				temp_frame = (GS_Buffer[0][CurrentCol]|GS_Buffer[1][CurrentCol]|GS_Buffer[2][CurrentCol]);	
				break;
			case 1:
				temp_frame = (GS_Buffer[0][CurrentCol]|GS_Buffer[1][CurrentCol]);
				break;
			case 2:
				temp_frame = (GS_Buffer[0][CurrentCol] | (GS_Buffer[1][CurrentCol]&GS_Buffer[2][CurrentCol]));	
				break;
			case 3:
				temp_frame = (GS_Buffer[0][CurrentCol]);	
				break;
			case 4:
				temp_frame = (GS_Buffer[0][CurrentCol] & (GS_Buffer[1][CurrentCol]|GS_Buffer[2][CurrentCol]));	
				break;	
			case 5:
				temp_frame = (GS_Buffer[0][CurrentCol] & GS_Buffer[1][CurrentCol]);
				break;
			case 6:
				temp_frame = (GS_Buffer[0][CurrentCol]&GS_Buffer[1][CurrentCol]&GS_Buffer[2][CurrentCol]);	
				break;				
		}
		outp(MASK_05&temp_frame,LED_DATA_PORT_05);
		LED_DATA_PORT_67 |= (MASK_67&temp_frame)>>6;
	}	
		
	//address columns backward - see if this helps brite stripe issue
	if (CurrentCol == 0)
	{	//if scan entire 8 columns, update the frame count
		CurrentCol = 7;
		CurrentFrame = (CurrentFrame + 1)%Gray_Scale;	//7 frames total
	}
	else CurrentCol--;
/*	
	CurrentCol++;
	if (CurrentCol >= 8)
	{	//if scan entire 8 columns, update the frame count
		CurrentCol = 0;
		CurrentFrame = (CurrentFrame + 1)%Gray_Scale;	//7 frames total
	}
	*/
}

void DisplayChar(unsigned char c,unsigned char col)
{
	DisplayBuffer[col]=c;
}


void LoadPattern_1byte(unsigned char pattern_byte)
{
	/*unsigned char lcv;
	
	for(lcv=0;lcv<8;lcv++)		
	{
		if (pattern_byte & (1<<lcv) )
			DisplayBuffer[lcv] = 0xff;
		else DisplayBuffer[lcv] = 0x00;
	}*/
	
	//should be done as above - but below is apparently 4 times faster!!!
	if (pattern_byte & (1<<0) ) DisplayBuffer[0] = 0xff; else DisplayBuffer[0] = 0x00;	
	if (pattern_byte & (1<<1) ) DisplayBuffer[1] = 0xff; else DisplayBuffer[1] = 0x00;	
	if (pattern_byte & (1<<2) ) DisplayBuffer[2] = 0xff; else DisplayBuffer[2] = 0x00;	
	if (pattern_byte & (1<<3) ) DisplayBuffer[3] = 0xff; else DisplayBuffer[3] = 0x00;	
	if (pattern_byte & (1<<4) ) DisplayBuffer[4] = 0xff; else DisplayBuffer[4] = 0x00;	
	if (pattern_byte & (1<<5) ) DisplayBuffer[5] = 0xff; else DisplayBuffer[5] = 0x00;	 
	if (pattern_byte & (1<<6) ) DisplayBuffer[6] = 0xff; else DisplayBuffer[6] = 0x00;	
	if (pattern_byte & (1<<7) ) DisplayBuffer[7] = 0xff; else DisplayBuffer[7] = 0x00;
	
	Gray_Scale = 1;
}

void LoadPattern_3byte(unsigned char* pattern)
{
/*	unsigned char temp_char;
	unsigned char lcv;
	
	temp_char = *(pattern + 0);
	for(lcv=0;lcv<8;lcv++)  {
		if (temp_char & (1<<lcv) )
			GS_Buffer[0][lcv] = 0xff;
		else GS_Buffer[0][lcv] = 0x00;
	}
	
	temp_char = *(pattern + 1);
	for(lcv=0;lcv<8;lcv++)  {
		if (temp_char & (1<<lcv) )
			GS_Buffer[1][lcv] = 0xff;
		else GS_Buffer[1][lcv] = 0x00;
	}
	
	temp_char = *(pattern + 2);
	for(lcv=0;lcv<8;lcv++)	 {
		if (temp_char & (1<<lcv) )
			GS_Buffer[2][lcv] = 0xff;
		else GS_Buffer[2][lcv] = 0x00;
	}	*/
	
	//should be done as above - but below is apparently 4 times faster!!!
	if (*(pattern) & (1<<0) ) GS_Buffer[0][0] = 0xff; else GS_Buffer[0][0] = 0x00;
	if (*(pattern) & (1<<1) ) GS_Buffer[0][1] = 0xff; else GS_Buffer[0][1] = 0x00;
	if (*(pattern) & (1<<2) ) GS_Buffer[0][2] = 0xff; else GS_Buffer[0][2] = 0x00;
	if (*(pattern) & (1<<3) ) GS_Buffer[0][3] = 0xff; else GS_Buffer[0][3] = 0x00;
	if (*(pattern) & (1<<4) ) GS_Buffer[0][4] = 0xff; else GS_Buffer[0][4] = 0x00;
	if (*(pattern) & (1<<5) ) GS_Buffer[0][5] = 0xff; else GS_Buffer[0][5] = 0x00;
	if (*(pattern) & (1<<6) ) GS_Buffer[0][6] = 0xff; else GS_Buffer[0][6] = 0x00;
	if (*(pattern) & (1<<7) ) GS_Buffer[0][7] = 0xff; else GS_Buffer[0][7] = 0x00;

	if (*(pattern + 1) & (1<<0) ) GS_Buffer[1][0] = 0xff; else GS_Buffer[1][0] = 0x00;
	if (*(pattern + 1) & (1<<1) ) GS_Buffer[1][1] = 0xff; else GS_Buffer[1][1] = 0x00;
	if (*(pattern + 1) & (1<<2) ) GS_Buffer[1][2] = 0xff; else GS_Buffer[1][2] = 0x00;
	if (*(pattern + 1) & (1<<3) ) GS_Buffer[1][3] = 0xff; else GS_Buffer[1][3] = 0x00;
	if (*(pattern + 1) & (1<<4) ) GS_Buffer[1][4] = 0xff; else GS_Buffer[1][4] = 0x00;
	if (*(pattern + 1) & (1<<5) ) GS_Buffer[1][5] = 0xff; else GS_Buffer[1][5] = 0x00;
	if (*(pattern + 1) & (1<<6) ) GS_Buffer[1][6] = 0xff; else GS_Buffer[1][6] = 0x00;
	if (*(pattern + 1) & (1<<7) ) GS_Buffer[1][7] = 0xff; else GS_Buffer[1][7] = 0x00;

	if (*(pattern + 2) & (1<<0) ) GS_Buffer[2][0] = 0xff; else GS_Buffer[2][0] = 0x00;
	if (*(pattern + 2) & (1<<1) ) GS_Buffer[2][1] = 0xff; else GS_Buffer[2][1] = 0x00;
	if (*(pattern + 2) & (1<<2) ) GS_Buffer[2][2] = 0xff; else GS_Buffer[2][2] = 0x00;
	if (*(pattern + 2) & (1<<3) ) GS_Buffer[2][3] = 0xff; else GS_Buffer[2][3] = 0x00;
	if (*(pattern + 2) & (1<<4) ) GS_Buffer[2][4] = 0xff; else GS_Buffer[2][4] = 0x00;
	if (*(pattern + 2) & (1<<5) ) GS_Buffer[2][5] = 0xff; else GS_Buffer[2][5] = 0x00;
	if (*(pattern + 2) & (1<<6) ) GS_Buffer[2][6] = 0xff; else GS_Buffer[2][6] = 0x00;
	if (*(pattern + 2) & (1<<7) ) GS_Buffer[2][7] = 0xff; else GS_Buffer[2][7] = 0x00;
}


void LoadPattern(unsigned char* pattern)
{
	//unsigned char j;
	
	//if (Map_flag){
	/* this is experimental ,- should work, but commented out for now...	
		for (j = 0; j < 8; j++){
		
			same = (*(pattern + j));
			opp = !same;
			switch(Zero_map) {	//first compute the mapping for the zeros
				case 0:	Frame1_0 = 0x00; Frame2_0 = 0x00;  Frame3_0 = 0x00;        					
					break;
				case 1: Frame1_0 = 0x00; Frame2_0 = 0x00;  Frame3_0 = opp;					
					break;
				case 2: Frame1_0 = 0x00; Frame2_0 = opp;  Frame3_0 = 0x00;					
					break;
				case 3: Frame1_0 = 0x00; Frame2_0 = opp;  Frame3_0 = opp;					
					break;
				case 4: Frame1_0 = opp; Frame2_0 = 0x00;  Frame3_0 = 0x00;					
					break;	
				case 5: Frame1_0 = opp; Frame2_0 = 0x00;  Frame3_0 = opp;					
					break;
				case 6: Frame1_0 = opp; Frame2_0 = opp;  Frame3_0 = 0x00;	
					break;
				case 7: Frame1_0 = opp; Frame2_0 = opp;  Frame3_0 = opp;	
					break;				
			} //end of switch(Zero_map)
			//use the mapping for the zeros and OR this with the mapping for the ones, to fill the GS_Buffer		
			switch(One_map) {
				case 0:	//Frame1_1 = 0x00; Frame2_1 = 0x00;  Frame3_1 = 0x00;
					GS_Buffer[0][j] = Frame1_0; 
					GS_Buffer[1][j] = Frame2_0; 
					GS_Buffer[2][j] = Frame3_0;        					
					break;
				case 1: //Frame1_1 = 0x00; Frame2_1 = 0x00;  Frame3_1 = same;
					GS_Buffer[0][j] = Frame1_0; 
					GS_Buffer[1][j] = Frame2_0; 
					GS_Buffer[2][j] = same | Frame3_0;        					
					break;
				case 2: //Frame1_1 = 0x00; Frame2_1 = same;  Frame3_1 = 0x00;
					GS_Buffer[0][j] = Frame1_0; 
					GS_Buffer[1][j] = same | Frame2_0; 
					GS_Buffer[2][j] = Frame3_0;  					
					break;
				case 3: //Frame1_1 = 0x00; Frame2_1 = same;  Frame3_1 = same;
					GS_Buffer[0][j] = Frame1_0; 
					GS_Buffer[1][j] = same | Frame2_0; 
					GS_Buffer[2][j] = same | Frame3_0;  
					break;
				case 4: //Frame1_1 = same; Frame2_1 = 0x00;  Frame3_1 = 0x00;
					GS_Buffer[0][j] = same | Frame1_0; 
					GS_Buffer[1][j] = Frame2_0; 
					GS_Buffer[2][j] = Frame3_0;  
					break;	
				case 5: //Frame1_1 = same; Frame2_1 = 0x00;  Frame3_1 = same;
					GS_Buffer[0][j] = same | Frame1_0; 
					GS_Buffer[1][j] = Frame2_0; 
					GS_Buffer[2][j] = same | Frame3_0;  
					break;
				case 6: //Frame1_1 = same; Frame2_1 = same;  Frame3_1 = 0x00;
					GS_Buffer[0][j] = same | Frame1_0; 
					GS_Buffer[1][j] = same | Frame2_0; 
					GS_Buffer[2][j] = Frame3_0;  
					break;
				case 7: //Frame1_1 = same; Frame2_1 = same;  Frame3_1 = same;
					GS_Buffer[0][j] = same | Frame1_0; 
					GS_Buffer[1][j] = same | Frame2_0; 
					GS_Buffer[2][j] = same | Frame3_0;  
					break;				
			} //end of switch(Zero_map)

		}//end of for loop

		Gray_Scale = 7;
	}//end of if statement 
	
	else	//fill the 8 byte DisplayBuffer
	{   */
		DisplayBuffer[0] = (*(pattern + 0));
		DisplayBuffer[1] = (*(pattern + 1));
		DisplayBuffer[2] = (*(pattern + 2));
		DisplayBuffer[3] = (*(pattern + 3));
		DisplayBuffer[4] = (*(pattern + 4));
		DisplayBuffer[5] = (*(pattern + 5));
		DisplayBuffer[6] = (*(pattern + 6));
		DisplayBuffer[7] = (*(pattern + 7));
		Gray_Scale = 1;
	// }
}


void LoadPattern16(unsigned char* pattern)
{
	GS_Buffer[0][0] = (*(pattern + 0));
	GS_Buffer[0][1] = (*(pattern + 1));
	GS_Buffer[0][2] = (*(pattern + 2));
	GS_Buffer[0][3] = (*(pattern + 3));
	GS_Buffer[0][4] = (*(pattern + 4));
	GS_Buffer[0][5] = (*(pattern + 5));
	GS_Buffer[0][6] = (*(pattern + 6));
	GS_Buffer[0][7] = (*(pattern + 7));
	
	GS_Buffer[1][0] = (*(pattern + 8));
	GS_Buffer[1][1] = (*(pattern + 9));
	GS_Buffer[1][2] = (*(pattern + 10));
	GS_Buffer[1][3] = (*(pattern + 11));
	GS_Buffer[1][4] = (*(pattern + 12));
	GS_Buffer[1][5] = (*(pattern + 13));
	GS_Buffer[1][6] = (*(pattern + 14));
	GS_Buffer[1][7] = (*(pattern + 15));
}


void LoadPattern24(unsigned char* pattern)
{
	GS_Buffer[0][0] = (*(pattern + 0));
	GS_Buffer[0][1] = (*(pattern + 1));
	GS_Buffer[0][2] = (*(pattern + 2));
	GS_Buffer[0][3] = (*(pattern + 3));
	GS_Buffer[0][4] = (*(pattern + 4));
	GS_Buffer[0][5] = (*(pattern + 5));
	GS_Buffer[0][6] = (*(pattern + 6));
	GS_Buffer[0][7] = (*(pattern + 7));
	
	GS_Buffer[1][0] = (*(pattern + 8));
	GS_Buffer[1][1] = (*(pattern + 9));
	GS_Buffer[1][2] = (*(pattern + 10));
	GS_Buffer[1][3] = (*(pattern + 11));
	GS_Buffer[1][4] = (*(pattern + 12));
	GS_Buffer[1][5] = (*(pattern + 13));
	GS_Buffer[1][6] = (*(pattern + 14));
	GS_Buffer[1][7] = (*(pattern + 15));
	
	GS_Buffer[2][0] = (*(pattern + 16));
	GS_Buffer[2][1] = (*(pattern + 17));
	GS_Buffer[2][2] = (*(pattern + 18));
	GS_Buffer[2][3] = (*(pattern + 19));
	GS_Buffer[2][4] = (*(pattern + 20));
	GS_Buffer[2][5] = (*(pattern + 21));
	GS_Buffer[2][6] = (*(pattern + 22));
	GS_Buffer[2][7] = (*(pattern + 23));
}



void LoadPatternEEP(unsigned char *pattern)
{
	DisplayBuffer[0] = eeprom_rb((uint8_t*)(pattern + 0));
	DisplayBuffer[1] = eeprom_rb((uint8_t*)(pattern + 1));
	DisplayBuffer[2] = eeprom_rb((uint8_t*)(pattern + 2));
	DisplayBuffer[3] = eeprom_rb((uint8_t*)(pattern + 3));
	DisplayBuffer[4] = eeprom_rb((uint8_t*)(pattern + 4));
	DisplayBuffer[5] = eeprom_rb((uint8_t*)(pattern + 5));
	DisplayBuffer[6] = eeprom_rb((uint8_t*)(pattern + 6));
	DisplayBuffer[7] = eeprom_rb((uint8_t*)(pattern + 7));
}

void StorePattern(unsigned char patternNumber, unsigned char *pattern)
{	
	PATTERNS[patternNumber][0] = (*(pattern + 0));
	PATTERNS[patternNumber][1] = (*(pattern + 1));
	PATTERNS[patternNumber][2] = (*(pattern + 2));
	PATTERNS[patternNumber][3] = (*(pattern + 3));
	PATTERNS[patternNumber][4] = (*(pattern + 4));
	PATTERNS[patternNumber][5] = (*(pattern + 5));
	PATTERNS[patternNumber][6] = (*(pattern + 6));
	PATTERNS[patternNumber][7] = (*(pattern + 7));
}


// delay for a minimum of <us> microseconds (from P. Stang)
// the time resolution is dependent on the time the loop takes 
// e.g. with 8Mhz and 5 cycles per loop, the resolution is 0.625 us 
void delay(unsigned short us) 
{
	unsigned short delay_loops;
	register unsigned short i;
	delay_loops = (us+3)/5*CYCLES_PER_US; // +3 for rounding up (rough) 
	// one loop takes 5 cpu cycles 
	for (i=0; i < delay_loops; i++) {};
} 

//for longer delays, use this function - gives delay
//time in ms. Can delay up to about 1 minute.
void long_delay(unsigned short ms) 
{
	register unsigned short i;
	for (i=0; i < ms; i++)
	{
	delay(1000);	
	};
} 


// resets the chip
void SystemReset()
{
asm volatile ("cli"); // turn off interrupts
WDTCR = _BV(WDE) | _BV(WDP2); // init WatchDog
while (1) asm volatile ("nop"); // wait for reset
}

void DisplayNum()
//display the current panel ID, for numbers upto 127
//this will in fact coorectly enumerate beyond 127 to 199
{
	int i, dig1, dig2, One_mask;
	//create a mask to append a row on top if the ID > 99
	if (deviceAddr > 99)	One_mask = 0x01;
	else		One_mask = 0x00;	
	
	dig1 = (deviceAddr%100)/10;
	dig2 = (deviceAddr%100)%10;
		
	for (i = 0; i < 4; i++)	//first character
	{ DisplayChar( (eeprom_rb((uint8_t*)(&NUMS[dig1][i])))|One_mask ,i);    }	
	for (i = 4; i < 8; i++) //second character
	{ DisplayChar( (eeprom_rb((uint8_t*)(&NUMS[dig2][i-4])))|One_mask ,i); 	}	
}

