/*
    TWI Header File
    By Robert Bailey
    
    Revision History:
    07.31.2003      RB      Created
*/

/* Description: This is the header file that defines values needed for the
    operation of the Hardware TWI */

/***********************************************************************/

/* Constants */
#define TWI_BUF_SIZE 16			/* buffer size */
/*#define TWI_BIT_RATE 128  */
#define TWI_BIT_RATE 10
#define TWI_PRESCALER 0

#define START_TX 0x08
#define SLAW_TX_ACK_RX 0x18
#define DATA_TX_ACK_RX 0x28
#define SLAW_RX_ACK_TX 0x60
#define GENC_RX_ACK_TX 0x70
#define SDATA_RX_ACK_TX 0x80
#define GDATA_RX_ACK_TX 0x90
#define STOP_RX 0xA0

#define CTRLC 3
#define CR 13
#define LF 10
#define BKSPC 8
/* End Constants */

/* Function Prototypes */
void TWI_Init(void);
void TWI_Putchar(unsigned char c,unsigned char slave_addr);
void TWI_Putchars(unsigned char* buf,int cnt,unsigned char slave_addr);
unsigned char TWI_Getchar(void);
unsigned char TWI_CharReady(void);
/* End Function Prototypes */
//added by MBR
void Send_Number(unsigned char target_panel_addr, long long number);
