/*
  FIFO Read Routines
  By Robert Bailey
	
  Revision History:
  07.29.04  RB  Created
*/

#include "fifo_read.h"
#include "ser128.h"
#include "legacy.h"

#include <avr/io.h>

void FIFO_Read_Init(void)
{
  FIFO_DATA_PORT=0x00;    /* clear the data port */
  FIFO_DATA_DDR=0x00;     /* and set to read */
  
  
  cbi(FIFO_RCLK_PORT,FIFO_RCLK_PIN);      /* clear rclk */
  sbi(FIFO_RCLK_DDR,FIFO_RCLK_PIN);       /* write */
  
  sbi(FIFO_REN_PORT,FIFO_REN_PIN);        /* clear ren */
  sbi(FIFO_REN_DDR,FIFO_REN_PIN);         /* write */
  
  sbi(FIFO_OE_PORT,FIFO_OE_PIN);          /* clear oe */
  sbi(FIFO_OE_DDR,FIFO_OE_PIN);           /* write */
}

unsigned char FIFO_read_byte(void)
{
  unsigned char data_in;
  
  cbi(FIFO_OE_PORT,FIFO_OE_PIN);          /* set oe */
  cbi(FIFO_REN_PORT,FIFO_REN_PIN);        /* set ren */
  
  /* pulse read clock */
  sbi(FIFO_RCLK_PORT,FIFO_RCLK_PIN);      /* set rclk */
  sbi(FIFO_REN_PORT,FIFO_REN_PIN);        /* clear ren */
  cbi(FIFO_RCLK_PORT,FIFO_RCLK_PIN);      /* clear rclk */
  
  data_in = inp(FIFO_DATA_PORT_IN);
  
  sbi(FIFO_OE_PORT,FIFO_OE_PIN);          /* set oe */
 
  return data_in;
}
