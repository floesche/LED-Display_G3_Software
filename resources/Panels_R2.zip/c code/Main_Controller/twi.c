/*
    TWI Routines
    By Robert Bailey
    
    Revision History:
    07.31.2003      RB      Created
*/

/* Description: These routines carry out the operation of the Hardware TWI */

/* Table of Contents
        TWI_Init                Initializes the TWI and TWI routines
        TWI_Putchar             Places a char in the Tx buffer to be Tx-ed
        TWI_Getchar             Blocking function that gets a char from
                                Rx buffer
        TWI_CharReady           Checks if anything is in the Rx buffer
*/

/***********************************************************************/

/* Include Section */
#include "twi.h"

#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>
/* End Include Section */

/* Variables Section */
volatile unsigned int twi_tx_buf_cnt;       /* number of buffer slots used */
volatile unsigned int twi_rx_buf_cnt;
unsigned char *twi_tx_tail_ptr, *twi_tx_head_ptr;       /* buffer pointers */
unsigned char *twi_rx_tail_ptr, *twi_rx_head_ptr;
unsigned char twi_tx_buffer[TWI_BUF_SIZE];              /* buffers */
unsigned char twi_rx_buffer[TWI_BUF_SIZE];

unsigned char twi_addr_rw;
/* End Variables Section */

/* Code Section */
void TWI_Init(void)
{
    cli();                                      /* disable interrupts */
    
    /* set up buffers */
	twi_tx_buf_cnt = twi_rx_buf_cnt = 0;
	twi_tx_tail_ptr = twi_tx_head_ptr = twi_tx_buffer;
	twi_rx_tail_ptr = twi_rx_head_ptr = twi_rx_buffer;
    
    /* set up TWI hardware */
    outp(TWI_BIT_RATE,TWBR);                    /* set bit rate register */
    outp(inp(TWSR)|TWI_PRESCALER,TWSR);         /* set prescaler bits */
    sbi(TWAR,TWGCE);                            /* enable general call */
    /* enable TWI and interrupt */
    outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
    
    sei();                                      /* enable interrupts */
}

void TWI_Putchar(unsigned char c,unsigned char slave_addr)
{
    while(twi_tx_buf_cnt);              /* wait until buffer is empty */
    
    cli();
    twi_tx_buf_cnt++;                   /* increment buffer count */
    *twi_tx_tail_ptr=c;                 /* store char in buffer */
    /* wrap tail pointer if needed */
    if (++twi_tx_tail_ptr >= (twi_tx_buffer + TWI_BUF_SIZE))
        twi_tx_tail_ptr=twi_tx_buffer;
    sei();
    
    twi_addr_rw = slave_addr << 1;        /* set SLA_W */
    
    /* send start condition */
    outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)|(1<<TWSTA)),TWCR);
}

void TWI_Putchars(unsigned char* buf,int cnt,unsigned char slave_addr)
{
    int i;
    while(twi_tx_buf_cnt);              /* wait until buffer is empty */
    
    i=0;
    cli();
    while(i<cnt)
    {
      twi_tx_buf_cnt++;                   /* increment buffer count */
      *twi_tx_tail_ptr=*(buf+i);            /* store char in buffer */
      /* wrap tail pointer if needed */
      if (++twi_tx_tail_ptr >= (twi_tx_buffer + TWI_BUF_SIZE))
          twi_tx_tail_ptr=twi_tx_buffer;
      i++;
    }
    sei();
    
    twi_addr_rw = slave_addr << 1;        /* set SLA_W */
    
    /* send start condition */
    outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)|(1<<TWSTA)),TWCR);
}

unsigned char TWI_Getchar(void)
{
    unsigned char c;
    
    while(!(twi_rx_buf_cnt));       /* wait for a character */
    
    cli();                          /* disable interrupts for critical code */
    twi_rx_buf_cnt--;               /* decrement the buffer count */
    c=*twi_rx_head_ptr;             /* get char from buffer */
    /* wrap head pointer if needed */
    if(++twi_rx_head_ptr >= (twi_rx_buffer + TWI_BUF_SIZE))
        twi_rx_head_ptr = twi_rx_buffer;
    sei();                          /* enable interrupts */
    
    return c;
}

unsigned char TWI_CharReady(void)
{
    return twi_rx_buf_cnt;
}

SIGNAL(SIG_2WIRE_SERIAL)
{
    switch(inp(TWSR) & 0xF8)
    {
        case START_TX:
            outp(twi_addr_rw,TWDR);             /* set SLA_W */
            outp(((1<<TWINT)|(1<<TWEN)|(1<<TWEA)|(1<<TWIE)),TWCR);
            break;
        
        case SLAW_TX_ACK_RX:
            if (twi_tx_buf_cnt) 
            {
                outp(*twi_tx_head_ptr, TWDR);   /* write byte out */
                twi_tx_buf_cnt--;
                /* wrap head pointer if needed */
                if(++twi_tx_head_ptr >= (twi_tx_buffer + TWI_BUF_SIZE))
                    twi_tx_head_ptr = twi_tx_buffer;
            }
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
        
        case DATA_TX_ACK_RX:
            if (twi_tx_buf_cnt) 
            {
                outp(*twi_tx_head_ptr, TWDR);   /* write byte out */
                twi_tx_buf_cnt--;
                /* wrap head pointer if needed */
                if(++twi_tx_head_ptr >= (twi_tx_buffer + TWI_BUF_SIZE))
                    twi_tx_head_ptr = twi_tx_buffer;
                /* send next byte */
                outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            }
            else
            {
                /* send stop */
                outp((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)|(1<<TWSTO),TWCR);
            }
            break;
        
        case SLAW_RX_ACK_TX:
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
        
        case GENC_RX_ACK_TX:
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
        
        case SDATA_RX_ACK_TX:
            if(!(twi_rx_buf_cnt>=TWI_BUF_SIZE))
            {
                twi_rx_buf_cnt++;                   /* increment buffer count */
	            *twi_rx_tail_ptr=inp(TWDR);         /* store char in buffer */
                /* wrap tail pointer if needed */
                if (++twi_rx_tail_ptr >= (twi_rx_buffer + TWI_BUF_SIZE))
                    twi_rx_tail_ptr=twi_rx_buffer;
            }
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
        
        case GDATA_RX_ACK_TX:
            if(!(twi_rx_buf_cnt>=TWI_BUF_SIZE))
            {
                twi_rx_buf_cnt++;                   /* increment buffer count */
	            *twi_rx_tail_ptr=inp(TWDR);         /* store char in buffer */
                /* wrap tail pointer if needed */
                if (++twi_rx_tail_ptr >= (twi_rx_buffer + TWI_BUF_SIZE))
                    twi_rx_tail_ptr=twi_rx_buffer;
            }
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
        
        case STOP_RX:
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
        
        default:
            outp(((1<<TWINT)|(1<<TWEA)|(1<<TWEN)|(1<<TWIE)),TWCR);
            break;
    }
}

/* End Code Section */

void Send_Number(unsigned char target_panel_addr, long long number)
{
	unsigned char NUM[8];
	int j;
		
	for (j = 0; j < 8; j++)
	{
		NUM[j] = ((unsigned char*)&number)[j];
	}
	TWI_Putchars(&NUM[0],8,target_panel_addr);
}
