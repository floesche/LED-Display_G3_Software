/*
  FIFO Read Routines
  By Robert Bailey
*/

/*
Description: Header file for fifo read routines. Contains definitions 
              required for the fifo read interface.
*/

/* FIFO Read Definitions */
  /* Port Definitions */
#define FIFO_DATA_PORT PORTA
#define FIFO_DATA_DDR DDRA
#define FIFO_DATA_PORT_IN PINA

#define FIFO_RCLK_PIN PG0
#define FIFO_RCLK_PORT PORTG
#define FIFO_RCLK_DDR DDRG

#define FIFO_REN_PIN PG1
#define FIFO_REN_PORT PORTG
#define FIFO_REN_DDR DDRG

#define FIFO_OE_PIN PG2
#define FIFO_OE_PORT PORTG
#define FIFO_OE_DDR DDRG

/* function prototypes */
void FIFO_Read_Init(void);
unsigned char FIFO_read_byte(void);
