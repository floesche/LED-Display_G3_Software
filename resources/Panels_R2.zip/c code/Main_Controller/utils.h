/*
  utils.h - utility functions Header File
  by MBR
*/

#include "a2d.h"
#include "i2c.h"
#include "fifo_read.h"
#include "ser128.h"
#include "handler.h"
#include <avr/pgmspace.h>

// some useful macros
#define bit_get(p,m) ((p) & (m))
#define bit_set(p,m) ((p) |= (m))
#define bit_clear(p,m) ((p) &= ~(m))
#define bit_flip(p,m) ((p) ^= (m))
#define bit_write(c,p,m) (c ? bit_set(p,m) : bit_clear(p,m))
#define BIT(x) (0x01 << (x))
#define LONGBIT(x) ((unsigned long)0x00000001 << (x))

/* Definitions */
#define X_DAC_ADDR 0x4C
#define Y_DAC_ADDR 0x4E

/* Routine Prototypes */
void init_all(void);
void LED_Blink(void);
void test_ADC(unsigned char ch);
void test_DIO(unsigned char ch);
void delay(unsigned short us);
void long_delay(unsigned short ms); 
void write_n_bytes(unsigned char *buffer, unsigned char message_length);
void SystemReset(void);