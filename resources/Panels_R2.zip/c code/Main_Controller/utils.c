// utils.c this file contains utility functions for mainctrl to call
#include "utils.h"
#include <avr/io.h>
#include "legacy.h"

extern int stop;  //only necessary if using stop command from mainctrl file - not doing so yet.

void init_all(void)
{
  //set LED pins to outputs
  outp(((1<<PORTE2)|(1<<PORTE3)),DDRE);	
  PORTE = 0xff; //turn LEDS off
    
  bit_flip(PORTE,BIT(2));  //turn on "power" LED
  
  //there are 4 INT lines available, for now these are set as Digital outputs
  DDRE |= ( DDRE|BIT(4)|BIT(5)|BIT(6)|BIT(7) );	
  //  outp( ( DDRE|BIT(4)|BIT(5)|BIT(6)|BIT(7) ),DDRE);	
  
  //enable  PC1 as CCON2 as output from main to CF
  outp((1<<PORTC1),DDRC);	
    
  outp(((1<<PORTF0)|(1<<PORTF1)),DDRF);	//for using port F for debugging
  
  //disable laser lines
  bit_clear(PORTE,BIT(6));
  bit_clear(PORTE,BIT(7)); 
 
  // initialize the UARTs	
  UART_Init(0);
  UART_Init(1);
  
  // initialize the FIFO for reading
  FIFO_Read_Init();
  long_delay(1000);
  
  //TWI_Init();
  i2cInit();
  i2cSetBitrate(500);
  
  //a2d init
  a2dInit();		
  // configure a2d port (PORTF) as input so we can receive analog signals
  DDRF = 0x00;
  // make sure pull-up resistors are turned off
  PORTF = 0x00;
  // set the a2d prescaler (clock division ratio)
  a2dSetPrescaler(ADC_PRESCALE_DIV32);
  // set the a2d reference
  a2dSetReference(ADC_REFERENCE_AVCC);
  
  Handler_Init();				/* setup handlers for timer-based interrupts*/
  
}


void LED_Blink(void)
{ 
	/* blink the second LED, this is a simple debug tool to see if the controller is responsive */
	int j;
  	
	for(j=0;j<10;j++)
	{
		bit_flip(PORTE,BIT(3));  //toggle LED
		long_delay(350);		
	}
  
 }
 
 void test_ADC(unsigned char ch)
 { 
	unsigned char X_data[3]={0x10,0x00,0x00};
	unsigned char Y_data[3]={0x10,0x00,0x00};
	u16 X_dac_val;
	u08 ADC_val;
	u08 j; 
	u08 k;
		
	for (k = 0; k < 30; k++)
	{
		for (j = 0; j < 200; j++)
		{	if (j < 100)
			X_dac_val = 1000 + 512*(u16)j; 	// build the up part of the triangle wave
			else
			X_dac_val = 1000 + 512*(u16)(100 + (100 - j)); // build the down part of the triangle wave
 	
			X_data[1] = ((unsigned char*)&X_dac_val)[1];
			X_data[2] = ((unsigned char*)&X_dac_val)[0];
			i2cMasterSend(X_DAC_ADDR, 3, X_data);
			
			ADC_val = a2dConvert8bit(ch);   //1v = 102 -> ~5 TIMES THE GAIN OF OL
			
			Y_data[1] = ADC_val;
			Y_data[2] = 0;
			i2cMasterSend(Y_DAC_ADDR, 3, Y_data);
			long_delay(2);			
		}
		bit_flip(PORTE,BIT(3));  //toggle LED, once per triangle wave pulse
	}	 	
}
 
void test_DIO(unsigned char ch)
 { 
	unsigned char Y_data[3]={0x10,0x00,0x00};
	u08 ADC_val;
	u08 k;
		
	for (k = 0; k < 60; k++)
	{
		//flip all 4 bits
		bit_flip(PORTE,BIT(4));  bit_flip(PORTE,BIT(5)); 
		bit_flip(PORTE,BIT(6));  bit_flip(PORTE,BIT(7)); 
		long_delay(100);			
		ADC_val = a2dConvert8bit(ch);   //1v = 102 -> ~5 TIMES THE GAIN OF OL
		long_delay(100);			
		Y_data[1] = ADC_val;
		Y_data[2] = 0;
		i2cMasterSend(Y_DAC_ADDR, 3, Y_data);		
		if (k % 2)
			bit_flip(PORTE,BIT(3));  //toggle LED, once per triangle wave pulse
	}	 	
}
 
// delay for a minimum of <us> microseconds (from P. Stang)
// the time resolution is dependent on the time the loop takes 
// e.g. with 8Mhz and 5 cycles per loop, the resolution is 0.625 us 
void delay(unsigned short us) 
{
	unsigned short delay_loops;
	register unsigned short i;
	delay_loops = (us+3)/5*CYCLES_PER_US; // +3 for rounding up (rough) 
	// one loop takes 5 cpu cycles 
	for (i=0; i < delay_loops; i++) {};
} 

//for longer delays, use this function - gives delay
//time in ms. Can delay up to about 1 minute.
void long_delay(unsigned short ms) 
{
	register unsigned short i;
	for (i=0; i < ms; i++)
	{
	delay(1000);	
	};
} 

void write_n_bytes(unsigned char *buffer, unsigned char message_length)
{	
	//mostly for debugging, will print an n byte message to the UART
	u08 j;
	
	for (j = 0; j < message_length; j++)
	{
		UART_Putstr(0,PSTR(" "));
		UART_SendNum(0,buffer[j]);
	}	
}

// resets the chip
void SystemReset()
{
asm volatile ("cli"); // turn off interrupts
WDTCR = _BV(WDE) | _BV(WDP2); // init WatchDog
while (1) asm volatile ("nop"); // wait for reset
}
