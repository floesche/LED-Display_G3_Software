#include "mainctrl.h"
#include "legacy.h"
#include "utils.h"
#include <stdlib.h>
#include <avr/io.h>

//globals - for now! - try to cut down on these
unsigned char Stop = 1;
unsigned char display_flag = 0;
unsigned char x_gt_y = 0;
unsigned char Laser_active = 0;

u16 x_num, y_num;	//the max index for x and y
u16 index_x, index_y; // the current index of x and y
u08 gs_value, bytes_per_panel_frame, row_compress, ident_compress;
u08 num_panels = 0;
u08 x_mode, y_mode;
u16 frame_num = 0;
u16 frame_num_old = 999;  //just chosen at random
s08 function_X[FUNCTION_LENGTH];
s08 function_Y[FUNCTION_LENGTH];
u16 function_counter = 0;
u08 divide_by_4_counter = 0;
s08 gain_x, gain_y, bias_x, bias_y;
s16 X_val, Y_val;
s16 X_pos_index, Y_pos_index;
u16 trigger_rate = 200;
	
int main(void)
{
    unsigned char message_length;
	unsigned char msg_buffer[55]; //buffer for comm with PC
	u16 lcv;
	
	init_all();
	for (lcv = 0; lcv < FUNCTION_LENGTH; lcv++)
		{ function_X[lcv] = function_Y[lcv] = 10;  }// here we use 10 as the equivalent for 1 V.		
	
	//initilializations
	X_pos_index = Y_pos_index = index_x = index_y = 0;
	bias_x = bias_y = 0;
	gain_x = gain_y = 10;
	x_mode = y_mode = 0;
	X_val = Y_val = 0;
	gs_value = 1;
	row_compress = 0;
    ident_compress = 0; // enable this to substitute simpler panael pattern for uniform pattern patches
	
	//wierd serial port error, see if removing this helps
	UART_CRLF(0);
	UART_Putstr(0,PSTR("Main Controller Works"));
	
	i2cMasterSend(0x00, 8, ALL_OFF);
	long_delay(1000);
	
	//now test the 1 byte sending
/*	for (lcv = 0; lcv < 8; lcv++)
		{ 	
		    i2cMasterSend(0x00, 1, TEST_BYTE[lcv]);
			long_delay(500);		
		}
	*/
	//now test the 3 byte sending
	for (lcv = 0; lcv < 9; lcv++)
		{ 	
		    i2cMasterSend(0x00, 3, TEST_3BYTE[lcv]);
			long_delay(100);		
		}
  
	LED_Blink();
    //do this again here, see if it helps with strange new serial port reading bug (June 06)
	//UART_Init(0);
	
	while(1)
	{  // this is the main loop, here we wait for communication from PC over UART 0
		if (UART_CharReady(0))	{
			message_length = fill_Rx_buffer(0, &msg_buffer[0]);
			switch(message_length) {
				case 1:  // if length 1, then decode...
					handle_message_length_1(&msg_buffer[0]);
					break;
				case 2: // if length 2, then decode, could be reset, display num, or change pat
					handle_message_length_2(&msg_buffer[0]);
					break;
				case 3: // if length 3, then decode...address change or ...
					handle_message_length_3(&msg_buffer[0]);
					break;
				case 5: // if length 5, then decode, set x,y index, or set gain, bias
					handle_message_length_5(&msg_buffer[0]);
					break;
				case 52: //if length 52, then this is function segment loading
					handle_message_length_52(&msg_buffer[0]);
					break;
				//default:
				//i2cMasterSend(0x00, 8, ERROR_CODES[6]);  
			} //end of switch
		}// end of if, goes to top if nothing received on UART
		
		// at bottom of while(1) loop, check to see if stop is 0, then unpdate display if the frame has changed.
		if (Stop == 0){	//only send out new pattern if the pattern index has changed
			if (frame_num != frame_num_old) {
				frame_num_old = frame_num; //update the 'old' frame number
				fetch_display_frame(frame_num);
			}
		}
	update_ANOUT();
	}
  return (0);
}

void handle_message_length_1(unsigned char *msg_buffer)
{
	switch(msg_buffer[0]) {
		case 0x20:	//Start display: 0x20
			//set these to zero so that start at beginning of function - useful for putting in a set amount of expansion
			function_counter = 0;	
			Stop = 0;
			display_flag = 0;  //clear the display flag
			Reg_Handler(Update_display, UPDATE_RATE, 1, 1);			
			Reg_Handler(increment_index_x, UPDATE_RATE, 2, 0); //initilize the 2 and 3 priority interupts to a fast rate so that
			Reg_Handler(increment_index_y, UPDATE_RATE, 3, 0); // the countdown is fast until the setting of the next rate 
			break;												//by the Update_display interupt. 					
			
		
		case 0x30: //stop display
			Stop = 1;
			//turn off the interupts
			Reg_Handler(Update_display, UPDATE_RATE,1,0);
			Reg_Handler(increment_index_x, UPDATE_RATE,2,0);
			Reg_Handler(increment_index_y, UPDATE_RATE,3,0);
			break;		
		
		case 0x25:	//Start display & trigger - same as regular, but this also does trigger
			//set these to zero so that start at beginning of function - useful for putting in a set amount of expansion
			function_counter = 0;	
			Stop = 0;
			display_flag = 0;  //clear the display flag
			Reg_Handler(Update_display, UPDATE_RATE, 1, 1);			
			Reg_Handler(increment_index_x, UPDATE_RATE, 2, 0); 
			Reg_Handler(increment_index_y, UPDATE_RATE, 3, 0); 			
			Reg_Handler(toggle_trigger, OVERFLOW_RATE/trigger_rate, 0, 1); //turn on the trigger toggle
			break;												
			
		case 0x35: //stop display & trigger - same as regular, but this also does trigger
			Stop = 1;
			//turn off the interupts
			Reg_Handler(Update_display, UPDATE_RATE,1,0);
			Reg_Handler(increment_index_x, UPDATE_RATE,2,0);
			Reg_Handler(increment_index_y, UPDATE_RATE,3,0);
			Reg_Handler(toggle_trigger, OVERFLOW_RATE/trigger_rate, 0, 0); //turn off the trigger toggle
			break;	
		
		case 0x00:  i2cMasterSend(0x00, 8, ALL_OFF); break;
    	case 0x40:  i2cMasterSend(0x00, 24, G_LEVELS[0]); break;
		case 0x41:  i2cMasterSend(0x00, 24, G_LEVELS[1]); break;
		case 0x42:  i2cMasterSend(0x00, 24, G_LEVELS[2]); break;
		case 0x43:  i2cMasterSend(0x00, 24, G_LEVELS[3]); 	break;
	    case 0x44:  i2cMasterSend(0x00, 24, G_LEVELS[4]); break;
		case 0x45:  i2cMasterSend(0x00, 24, G_LEVELS[5]); break;
		case 0x46:  i2cMasterSend(0x00, 24, G_LEVELS[6]); break;
		case 0x47:  i2cMasterSend(0x00, 24, G_LEVELS[7]); break;
		case 0xFF:  i2cMasterSend(0x00, 8, ALL_ON); break;
		case 0x50:  LED_Blink(); break;
		case 0x60:  SystemReset();  break;
		case 0x70:  benchmark_pattern(); break;
		
		case 0x10:  // turn laser on
			Laser_active = 1;			
			break;
			
		case 0x11:  // turn laser off
			Laser_active = 0;
			// turn off the two lines that may be connected 
			bit_clear(PORTE,BIT(6));
			bit_clear(PORTE,BIT(7)); 
			break;
		
		case 0x12:  // turn on compression for identical elements
			ident_compress = 1;
			break;
		
		case 0x13:  // turn off compression for identical elements
			ident_compress = 0;
			break;		
		
		default: i2cMasterSend(0x00, 8, ERROR_CODES[1]);  
	}
}

void handle_message_length_2(unsigned char *msg_buffer)
{
	unsigned char argument_byte;

	argument_byte = msg_buffer[1];
	switch(msg_buffer[0]) {
		case 0x01: //sends a reset command out to panel at taget address
			i2cMasterSend(argument_byte, 2, RESET); 
			break; 
					
		case 0x02: //sends a display command out to panel at taget address
			i2cMasterSend(argument_byte, 2, DISPLAY); 
			break; 	
		
		case 0x03:   //this is a set pattern
			set_pattern(argument_byte);			//pattern x - specified in argument_byte
		break;
		
		case 0x04: // this is an ADC test command
			test_ADC(argument_byte);  //here argument_byte is actually a channel, 0-7 to test ADC/DAC system
			break;

		case 0x05: // this is a DIO test command
			test_DIO(argument_byte);  //here argument_byte is actually a channel, 0-7 to test ADC/DAC system
			break;
		
		case 0x06: // this is a trigger rate set command
			trigger_rate = argument_byte*2;  //here argument_byte is a trigger rate 
			break;
		default: i2cMasterSend(0x00, 8, ERROR_CODES[2]);
	}
}		
void handle_message_length_3(unsigned char *msg_buffer)
{
	u08 target_panel_addr;
	unsigned char CMD[2];
	
	switch(msg_buffer[0]) {
		case 0xFF:
			target_panel_addr = msg_buffer[1];	//put in error check, in range < 127
			//sends a reset command out to panel at taget address
			i2cMasterSend(target_panel_addr, 2, RESET); 
			long_delay(300);
			CMD[0] = 0xFF; CMD[1] = msg_buffer[2];	 //send change address command
			i2cMasterSend(target_panel_addr, 2, CMD);				
			break;
			
		case 0x10:
			x_mode = msg_buffer[1];
			y_mode = msg_buffer[2];
			//put in an error message if value is not 0, 1, or 2.
			break;
		default: i2cMasterSend(0x00, 8, ERROR_CODES[3]); 
	}
}			

void handle_message_length_5(unsigned char *msg_buffer)
{
	switch(msg_buffer[0]) {
		case 0x70:   //put in a bunch of type casts, because of mysterious error dealling with frame index above 128.
			index_x = (unsigned char)msg_buffer[1] + (256*(unsigned char)msg_buffer[2]);		
			index_y = (unsigned char)msg_buffer[3] + (256*(unsigned char)msg_buffer[4]);	
			
			X_pos_index = index_x; // these only used during position func. control mode, but 
			Y_pos_index = index_y; //update here should not slow things down much and no need for sep. function.
			frame_num = ((u16)index_y)*((u16)x_num) + (u16)index_x;	
			display_flag = 0;  //clear the display flag
			fetch_display_frame(frame_num);					
			break;
		
		case 0x71:
			//all of these are signed byte values
			gain_x = msg_buffer[1];
			bias_x = msg_buffer[2];
			gain_y = msg_buffer[3];
			bias_y = msg_buffer[4];	
			break;   
		
		case 0x80:
			//all of these are singed byte values
			gain_x = msg_buffer[1];
			bias_x = msg_buffer[2];
			gain_y = msg_buffer[3];
			bias_y = msg_buffer[4];	
			break;   
						
		default:
			i2cMasterSend(0x00, 8, ERROR_CODES[4]);
	}	
}

void handle_message_length_52(unsigned char *msg_buffer)
{   
	u08 j;
	u16 function_start_addr;
	// load function command - 
	switch(msg_buffer[0]) {
	//first arg. identifies X or Y
	//second arg. is the function segment number,these are 50 byte length
	case 1:		//load function_X
		function_start_addr = msg_buffer[1]*50;
		for (j = 0; j < 50; j++)
			{ function_X[function_start_addr + j] = msg_buffer[j+2]; }		
		break;
			
	case 2:
		function_start_addr = msg_buffer[1]*50;
		for (j = 0; j < 50; j++)
			{ function_Y[function_start_addr + j] = msg_buffer[j+2]; }		
		break;
	}		
}



void update_ANOUT(void)
{
	unsigned char X_data[3]={0x10,0x00,0x00};
	unsigned char Y_data[3]={0x10,0x00,0x00};
	u16 X_dac_val, Y_dac_val;
	
	//there are five modes 0 - OL, 1 - CL, 2 - CL w Bias, 3 - POS mode, 4 - function DBG mode
	// for all modes except 4, the ANOUT should be the position of pattern, normalized to 5V.
	
	if (x_mode == 5)   // in function DBG mode - show the function gen
		X_dac_val = (65535/2) + 328*function_X[function_counter];   //328 should convert 1V (=20) to 0.5 V
	else	// in all other modes, show the pattern position
		X_dac_val = (index_x*65535)/x_num;
	// now make message and send to X DAC	
	X_data[1] = ((unsigned char*)&X_dac_val)[1];
	X_data[2] = ((unsigned char*)&X_dac_val)[0];
	i2cMasterSend(X_DAC_ADDR, 3, X_data);
	
	if (y_mode == 5)
		Y_dac_val = (65535/2) + 328*function_Y[function_counter];   //328 should convert 1V (=20) to 0.5 V
	else 	// in all other modes, show the pattern position
		Y_dac_val = (index_y*65535)/y_num;
	// now make message and send to Y DAC	
	Y_data[1] = ((unsigned char*)&Y_dac_val)[1];
	Y_data[2] = ((unsigned char*)&Y_dac_val)[0];
	i2cMasterSend(Y_DAC_ADDR, 3, Y_data);
	
	//also update the output lines for quadrant-type learning patterns
	if ((x_num == 96)&&(Laser_active == 1))
		{
			if ( ((index_x >= 0)&&(index_x <= 23)) || ((index_x >= 48)&&(index_x <= 71)) )
			{
			bit_set(PORTE,BIT(6));
			bit_clear(PORTE,BIT(7)); 
			}
			else
			{
			bit_clear(PORTE,BIT(6));
			bit_set(PORTE,BIT(7)); 
			}		
	}	
}


void fetch_display_frame(unsigned short f_num){
	// this function will fetch the current frame from the CF and display it.
	//pass in f_num instead of using global frame_num to ensure that the value of
	//frame_num does not change during this function's run
	u08 j, panel_index, packet_sent;
	unsigned char Tx_buffer[3];  //make this longer if longer messages will be sent
	unsigned char FLASH[24];
	
	cbi(PORTC,PORTC1);   // clear the 'I got frame' bit
	//0x00 then frame_number as unsigned 2 byte integer
	Tx_buffer[0] = 0x00;  	//send 0x00 then pat_ID
	Tx_buffer[1] = ((unsigned char*)&f_num)[0];
	Tx_buffer[2] = ((unsigned char*)&f_num)[1];
	send_Tx_buffer(1, &Tx_buffer[0], 3);		
	
	//put these next few lines here to give CF controller some time
	if (display_flag > 1){			//if flag gets bigger than 1 -> frame skipped
		bit_flip(PORTE,BIT(3));}  	//toggle LED
	display_flag = 0;  //clear the display flag
	
	loop_until_bit_is_set(PINC, PC0);  //wait until 'frame ready' bit is set by CF ctrl
	FIFO_read_byte();
	for (panel_index = 1; panel_index <= num_panels; panel_index++){	
		for(j=0;j<bytes_per_panel_frame;j++)
			{  FLASH[j] = FIFO_read_byte(); }
		packet_sent = 0; //used with compression to simplify coniditionals.
		
		// i2cMasterSend(panel_index, bytes_per_panel_frame, &FLASH[0]);
		if (ident_compress == 1) {
			if (bytes_per_panel_frame == 8){
				if( (FLASH[0] == FLASH[1])&&(FLASH[2] == FLASH[3])&&(FLASH[4] == FLASH[5])&&(FLASH[6] == FLASH[7]) ){
					if( (FLASH[1] == FLASH[2])&&(FLASH[3] == FLASH[4])&&(FLASH[5] == FLASH[6]) ){
					i2cMasterSend(panel_index, 1, &FLASH[0]); //send a 1 byte packet with the correct row_compressed value.
					packet_sent = 1;
					} //end of second round of comparisons
				} //end of first round of byte comparisons
			} // end of check if bytes_per_panel_frame is 8
		
			if (bytes_per_panel_frame == 24){
				if( (FLASH[0] == FLASH[1])&&(FLASH[2] == FLASH[3])&&(FLASH[4] == FLASH[5])&&(FLASH[6] == FLASH[7]) ){
					if( (FLASH[1] == FLASH[2])&&(FLASH[3] == FLASH[4])&&(FLASH[5] == FLASH[6]) ){
						if( (FLASH[8+0] == FLASH[8+1])&&(FLASH[8+2] == FLASH[8+3])&&(FLASH[8+4] == FLASH[8+5])&&(FLASH[8+6] == FLASH[8+7]) ){
							if( (FLASH[8+1] == FLASH[8+2])&&(FLASH[8+3] == FLASH[8+4])&&(FLASH[8+5] == FLASH[8+6]) ){
								if( (FLASH[16+0] == FLASH[16+1])&&(FLASH[16+2] == FLASH[16+3])&&(FLASH[16+4] == FLASH[16+5])&&(FLASH[16+6] == FLASH[16+7]) ){
									if( (FLASH[16+1] == FLASH[16+2])&&(FLASH[16+3] == FLASH[16+4])&&(FLASH[16+5] == FLASH[16+6]) ){	
										//use TX_buffer to make gscale pattern	
										Tx_buffer[0] = FLASH[0];
										Tx_buffer[1] = FLASH[8];
										Tx_buffer[2] = FLASH[16];
										i2cMasterSend(panel_index, 3, &Tx_buffer[0]); //send a 3 byte packet with the correct row_compressed value.
										packet_sent = 1;
									} //end of sixth round of comparisons
								} //end of fifth round of comparisons
							} //end of fourth round of comparisons
						} //end of third round of comparisons
					} //end of second round of comparisons
				} //end of first round of byte comparisons
			} // end of check if bytes_per_panel_frame is 24			
		} //end of if ident_compress == 1	
		
		if (packet_sent == 0){ //above conditionals rejected sending a simple pattern patch
			i2cMasterSend(panel_index, bytes_per_panel_frame, &FLASH[0]);} 		
	} //end of for all panels loop
	sbi(PORTC,PORTC1);   // set the 'I got pat' bit	
}


void Update_display(void)
{	
	s16 X_rate = 0;
	s16 Y_rate = 0;
	s16 X_ADC1, X_ADC2, Y_ADC1, Y_ADC2;
	s16 temp_ADC_val;
	
	//there are five modes 0 - OL, 1 - CL, 2 - CL w Bias, 3 - POS mode, 4 - function DBG mode
	
	switch(x_mode) {
		case 0:	 // open loop - use function generator to set x rate
			X_val = 2*function_X[function_counter];
			X_rate = (X_val*gain_x)/10 + 5*bias_x;  	
			break;	
		case 1: //closed loop, use CH0 - CH1 to set x rate
			X_ADC1 = a2dConvert10bit(0)/2; 	X_ADC2 = a2dConvert10bit(1)/2;  //1v = 102
			temp_ADC_val = X_val; //the previous value
			X_val = ( 6*temp_ADC_val + 4*(X_ADC1 - X_ADC2) )/10;   //this is a 60% old value, 40% new value smoother	
			X_rate = (X_val*gain_x)/10 + 5*bias_x;  	
			break;	
		case 2: //closed loop w bias - use CH0 - CH1, and function gen. to set x rate
			X_ADC1 = a2dConvert10bit(0)/2;  X_ADC2 = a2dConvert10bit(1)/2;  //1v = 102
			temp_ADC_val = X_val; //the previous value
			X_val = ( 6*temp_ADC_val + 4*(X_ADC1 - X_ADC2) )/10;   //this is a 60% old value, 40% new value smoother
			//add in the bias to CL mode on ch X
			X_rate = (X_val*gain_x)/10 + 2*function_X[function_counter] + 5*bias_x; 
			break;
		case 3: // POS mode, use CH4 to set the frame position (pos ctrl, not vel ctrl)
			X_ADC1 = a2dConvert10bit(4);  //used to use CH0, changed this so no need to change connections
			index_x = X_ADC1/gain_x + bias_x;
			if (index_x >= x_num)  {index_x = x_num - 1;} //check if too big
			if (index_x <= 0)  {index_x = 0;} //or too small
			frame_num = (index_y)*(x_num) + index_x;
			X_rate = 0; 
			break;
		case 4: 
			//only use temp_ADC_val as a temp variable, just not to create an additional one
			temp_ADC_val = (X_pos_index + (s16)function_X[function_counter]);
			if (temp_ADC_val >= 0) {index_x = temp_ADC_val%x_num; }
			if (temp_ADC_val < 0) {index_x = x_num - ((abs(temp_ADC_val))%x_num); }
			frame_num = (index_y)*(x_num) + index_x;
			X_rate = 0; 
			break;
		case 5:  // this is the function gen DBG mode - don't run x, set rate to zero
			X_rate = 0;  
			break;
			//do something with errors here for default case
	}
	
	switch(y_mode) {
		case 0:	 // open loop - use function generator to set x rate
			Y_val = 2*function_Y[function_counter];
			Y_rate = (Y_val*gain_y)/10 + 5*bias_y;  	
			break;	
		case 1: //closed loop, use CH2 - CH3 to set x rate
			Y_ADC1 = a2dConvert10bit(2)/2; 	Y_ADC2 = a2dConvert10bit(3)/2;  //1v = 102
			temp_ADC_val = Y_val; //the previous value
			Y_val = ( 6*temp_ADC_val + 4*(Y_ADC1 - Y_ADC2) )/10;   //this is a 60% old value, 40% new value smoother	
			Y_rate = (Y_val*gain_y)/10 + 5*bias_y;  	
			break;	
		case 2: //closed loop w bias - use CH2 - CH3, and function gen. to set x rate
			Y_ADC1 = a2dConvert10bit(0)/2;  Y_ADC2 = a2dConvert10bit(1)/2;  //1v = 102
			temp_ADC_val = Y_val; //the previous value
			Y_val = ( 6*temp_ADC_val + 4*(Y_ADC1 - Y_ADC2) )/10;   //this is a 60% old value, 40% new value smoother
			//add in the bias to CL mode on ch Y
			Y_rate = (Y_val*gain_y)/10 + 2*function_Y[function_counter] + 5*bias_y; 
			break;
		case 3: // POS mode, use CH5 to set the frame position (pos ctrl, not vel ctrl)
			Y_ADC1 = a2dConvert10bit(5);
			index_y = Y_ADC1/gain_y + bias_y;
			if (index_y >= y_num)  {index_y = y_num - 1;} //check if too big
			if (index_y <= 0)  {index_y = 0;} //or too small
			frame_num = (index_y)*(x_num) + index_x;
			Y_rate = 0; 
			break;
		case 4:
		//only use temp_ADC_val as a temp variable, just not to create an additional one
			temp_ADC_val = (Y_pos_index + (s16)function_Y[function_counter]);
			if (temp_ADC_val >= 0) {index_y = temp_ADC_val%y_num; }
			if (temp_ADC_val < 0) {index_y = y_num - ((abs(temp_ADC_val))%y_num);	}
			frame_num = (index_y)*(x_num) + index_x;
			Y_rate = 0; 
			break;
		case 5:  // this is the function gen DBG mode - don't run y, set rate to zero
			Y_rate = 0;  
			break;
			//do something with errors here for default case
	}
	
	//in the above x,y_val computation, there is a div by 10 to take away gain scaling
	//so gain_x of 10 is 1X gain, gain_x of 20 = 2X ...
	
	//here the 2* the rate is because we want 20 = 1V to correspond to 10 fps. could probably do without, 
	// and just divide the a2dConvert output by 4, and not scale function_x,y by 2
	
	if (X_rate > 0) 
		Update_Reg_Handler(increment_index_x, 2*(OVERFLOW_RATE/abs(X_rate)),2,1);
	else if (X_rate < 0) 
		Update_Reg_Handler(decrement_index_x, 2*(OVERFLOW_RATE/abs(X_rate)),2,1);
	else 		//X_rate == 0
		Update_Reg_Handler(decrement_index_x, (UPDATE_RATE),2,0);
		
	if (Y_rate > 0) 
		Update_Reg_Handler(increment_index_y, 2*(OVERFLOW_RATE/abs(Y_rate)),3,1);
	else if (Y_rate < 0) 
		Update_Reg_Handler(decrement_index_y, 2*(OVERFLOW_RATE/abs(Y_rate)),3,1);
	else  		//Y_rate == 0
		Update_Reg_Handler(decrement_index_y, (UPDATE_RATE),3,0);
	
	//if the rates are too high, track the largest one to set warning LED
	x_gt_y = (X_rate >= Y_rate);

	divide_by_4_counter++;
	//if (divide_by_4_counter == 4){
	if (divide_by_4_counter == 8){ //because now interrupt occurs 400 times per sec.
		divide_by_4_counter = 0;
		function_counter = (function_counter + 1)%FUNCTION_LENGTH;
	}		
}


void increment_index_x(void)
{	
	index_x++;
	if (index_x >= x_num)
		{index_x = 0;}	
	frame_num = (index_y)*(x_num) + index_x;
	if (x_gt_y) display_flag++;
}


void increment_index_y(void)
{	
	index_y++;
	if (index_y >= y_num)
		{index_y = 0;}	
	frame_num = (index_y)*(x_num) + index_x;	
	if (x_gt_y == 0) display_flag++;
}


void decrement_index_x(void)
{	
	if (index_x <= 0)    //just to be safe, use less than
		{index_x = x_num - 1;}		//but these are unsigned
	else	
		{index_x--;}	
	frame_num = (index_y)*(x_num) + index_x;
	if (x_gt_y) display_flag++;
}


void decrement_index_y(void)
{	
	if (index_y <= 0)    //just to be safe, use less than
		{index_y = y_num - 1;}		//but these are unsigned
	else	
		{index_y--;}
	frame_num = (index_y)*(x_num) + index_x;
	if (x_gt_y == 0) display_flag++;
}


void toggle_trigger(void)
{
	bit_flip(PORTE,BIT(4));  //turn on "power" LED
} 


void set_pattern(unsigned char pat_num)
{  //sets the pattern ID, in future return 0 or 1 if error/succeed
	unsigned char message_length;
	unsigned char Rx_buffer[6];  //make this longer if longer messages will be received		
	unsigned char Tx_buffer[2];  //make this longer if longer messages will be sent
	
	Tx_buffer[0] = 0x00;  	//send 0x00 then pat_ID
	Tx_buffer[1] = pat_num;			//pattern x - specified in target_panel_addr
	send_Tx_buffer(1, &Tx_buffer[0], 2);	
	long_delay(100);	
	
    while (!UART_CharReady(1));  //kill time until message arrives
	message_length = fill_Rx_buffer(1,&Rx_buffer[0]);
	if (message_length == 6){
		((unsigned char*)&x_num)[0] = Rx_buffer[0];
		((unsigned char*)&x_num)[1] = Rx_buffer[1];
		((unsigned char*)&y_num)[0] = Rx_buffer[2];
		((unsigned char*)&y_num)[1] = Rx_buffer[3];
		num_panels = Rx_buffer[4];
		gs_value = Rx_buffer[5];
		if ((gs_value >= 11) & (gs_value <= 13)) {
			gs_value = gs_value - 10;
			row_compress = 1;
			bytes_per_panel_frame = gs_value;
		}
		else {	
			row_compress = 0;
			bytes_per_panel_frame = gs_value*8;			
		}
		//bytes_per_panel_frame = gs_value*8;	
		index_x = index_y = 0;
		frame_num = 0;
		Stop = 1;
		long_delay(2);  //occasionally there is a read error on this first frame
		display_flag = 0;  //clear the display flag
		fetch_display_frame(frame_num);
	}					
	else{
		UART_CRLF(0);
		UART_Putstr(0,PSTR("error loading pattern"));
	}
}

void benchmark_pattern(void)
{ // this function assumes that a pattern has been set
	unsigned short num_frames;
	unsigned short frame_ind;
	unsigned char message_length;
	unsigned char Rx_buffer[1];  //make this longer if longer messages will be received		
	unsigned char Tx_buffer[1];  //make this longer if longer messages will be sent
	
	Stop = 1;
	num_frames = x_num*y_num;
		
	Tx_buffer[0] = 0xF0;  	//send 0xF0 for this test
	send_Tx_buffer(1, &Tx_buffer[0], 1);	
	long_delay(1);	
	
	//prepare next message
	Tx_buffer[0] = 0x0F;  	//send 0x0F for this to end
	
    while (!UART_CharReady(1));  //kill time until message arrives
	message_length = fill_Rx_buffer(1,&Rx_buffer[0]);
	if (message_length == 1)  // and content is e.g. 0x0F
	{
	for(frame_ind=0; frame_ind < num_frames; frame_ind++)
		fetch_display_frame(frame_ind);	
		
	// send this to stop the benchmark
	send_Tx_buffer(1, &Tx_buffer[0], 1);	
	
	}	
	else return;	
}



