
//*****************************************************************************
//
// File Name	: 'global.h'


// CPU clock speed
#define F_CPU        16000000               		// 16MHz processor
#define CYCLES_PER_US ((F_CPU+500000)/1000000) 	// cpu cycles per microsecond

// true/false defines
#define FALSE	0
#define TRUE	-1
	
// datatype definitions macros
typedef unsigned char  u08;
typedef   signed char  s08;
typedef unsigned short u16;
typedef   signed short s16;
typedef unsigned long  u32;
typedef   signed long  s32;
typedef unsigned long long u64;
typedef   signed long long s64;