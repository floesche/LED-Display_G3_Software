/*
  Compact Flash Routines
  By Robert Bailey
*/

/*
Description: Header file for compact flash routines. Contains definitions 
              required for the compact flash interface.
*/

/* CF Definitions */
  /* Port Definitions */
#define CF_DATA_LOW_OUT PORTB
#define CF_DATA_LOW_DDR DDRB
#define CF_DATA_LOW_IN PINB

#define CF_DATA_HIGH_OUT PORTC
#define CF_DATA_HIGH_DDR DDRC
#define CF_DATA_HIGH_IN PINC

#define CF_ADDR0_PIN PA0
#define CF_ADDR0_DDR DDRA
#define CF_ADDR0_PORT PORTA
#define CF_ADDR1_PIN PA1
#define CF_ADDR1_DDR DDRA
#define CF_ADDR1_PORT PORTA
#define CF_ADDR2_PIN PA2
#define CF_ADDR2_DDR DDRA
#define CF_ADDR2_PORT PORTA

#define CF_CS0_PIN PA3
#define CF_CS0_DDR DDRA
#define CF_CS0_PORT PORTA
#define CF_CS1_PIN PA4
#define CF_CS1_DDR DDRA
#define CF_CS1_PORT PORTA

#define CF_IORD_PIN PA5
#define CF_IORD_DDR DDRA
#define CF_IORD_PORT PORTA

#define CF_IOWR_PIN PA6
#define CF_IOWR_DDR DDRA
#define CF_IOWR_PORT PORTA

#define CF_RESET_PIN PA7
#define CF_RESET_DDR DDRA
#define CF_RESET_PORT PORTA

#define CF_IORDY_PIN PD1
#define CF_IORDY_DDR DDRD
#define CF_IORDY_PORT PORTD

/* CF ROUTINE PROTOTYPES */
void CF_Init(void);
void WaitBusy(void);
unsigned char cf_read_status(void);
unsigned int cf_read_word(void);
void cf_write_word(unsigned int data_out);
void cf_get_block(int *block,unsigned long lba);
void cf_get_partial_block(int *block,unsigned long lba, unsigned short num_words);
void cf_clear_data_port(void);

#define nop() asm volatile ("nop")
