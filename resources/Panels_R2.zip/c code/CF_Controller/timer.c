/*
	Timer Routines
	By Robert Bailey
	
	Revision History:
	09.29.02	RB	Created
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include "legacy.h"
#include "timer.h"


volatile unsigned long ticks=0;


SIGNAL(SIG_OVERFLOW0)			/*signal Handler for timer ovf 0 */
{
	ticks++;
}


void timer_init(void)
{
	unsigned char c;
	
	ticks=0;
	outp(0x02,TCCR0);		/*Prescaler = 8*/
	c=inp(TIMSK);
	outp((c | (1<<TOIE0)), TIMSK);	/*enable timer ovf irq*/
	sei();
}

void Wait(unsigned int delay)
{
	unsigned long temp=ticks;

	while(ticks - temp < delay);
}


void timer_fine_tic(void)
{
// set the 16 bit timer to zero, also set the prescaler to 8
// with prescaler = 8, counts happen every 16E6/8, so 2 counts are 1 us
// full count is (2^16)*(8)/(16E6) = 32.8 ms
	outp(0x02,TCCR1B);		/*Prescaler = 8*/
	outp(0, TCNT1H);		// reset TCNT1
	outp(0, TCNT1L);
}

unsigned short timer_fine_toc(void)
{
// read and return the 16 bit timer
	unsigned short del_t;
	((unsigned char*)&del_t)[0] = inp(TCNT1L);
	((unsigned char*)&del_t)[1] = inp(TCNT1H);
	return del_t;
}	


void timer_coarse_tic(void)
{
// set the 8 bit timer to zero, also set the prescaler to 8
// with prescaler = 8, overflow happens 16E6/(256*8) , so 7.8 counts are 1 ms
// with prescaler = 64, overflow happens 16E6/(256*864 , so roughly 1 count per ms
	unsigned char c;
	
	ticks=0;
	outp(0x02,TCCR0);		//Prescaler = 8
	outp(0, TCNT0);		// reset TCNT0
	c=inp(TIMSK);
	outp((c | (1<<TOIE0)), TIMSK);	//enable timer ovf irq
	sei();
}

unsigned long timer_coarse_toc(void)
{
// read and return the ticks counter
// to convert this value to ms - divide by 
	unsigned long del_t;	
	del_t = (unsigned long)ticks*256 + inp(TCNT0);
	return del_t;
}	



/*
void timer_coarse_tic(void)
{
// set the 16 bit timer to zero, also set the prescaler to 8
// with prescaler = 1024, counts happen every 16E6/1024, so 15.6 counts are 1 ms
// full count is (2^16)*(1024)/(16E6) = 4.19 s
	unsigned char c;
	
	ticks=0;
	outp(0x07,TCCR0);		/*Prescaler = 1024
	c=inp(TIMSK);
	outp((c | (1<<TOIE0)), TIMSK);	/*enable timer ovf irq
	sei();
	
	outp(0x07,TCCR1B);		/*Prescaler = 1024
	outp(0, TCNT1H);		// reset TCNT1
	outp(0, TCNT1L);
}

unsigned long timer_coarse_toc(void)
{
// read and return the 16 bit timer
	unsigned long del_t = 0;
	
	((unsigned char*)&del_t)[0] = inp(TCNT1L);
	((unsigned char*)&del_t)[1] = inp(TCNT1H);
	del_t = del_t + ticks*(1024*256);
	return del_t;
}	*/