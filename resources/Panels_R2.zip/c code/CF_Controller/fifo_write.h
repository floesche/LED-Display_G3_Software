/*
  FIFO Write Routines
  By Robert Bailey
*/

/*
Description: Header file for fifo write routines. Contains definitions 
              required for the fifo write interface.
*/

/* FIFO Write Definitions */
  /* Port Definitions */
#define FIFO_DATA_PORT PORTF
#define FIFO_DATA_DDR DDRF

#define FIFO_WCLK_PIN PE2
#define FIFO_WCLK_PORT PORTE
#define FIFO_WCLK_DDR DDRE

#define FIFO_WEN1_PIN PE3
#define FIFO_WEN1_PORT PORTE
#define FIFO_WEN1_DDR DDRE

#define FIFO_WEN2_PIN PE4
#define FIFO_WEN2_PORT PORTE
#define FIFO_WEN2_DDR DDRE

#define FIFO_PAF_PIN PG0
#define FIFO_PAF_PORT PORTG
#define FIFO_PAF_IN PING
#define FIFO_PAF_DDR DDRG

#define FIFO_PAE_PIN PG1
#define FIFO_PAE_PORT PORTG
#define FIFO_PAE_IN PING
#define FIFO_PAE_DDR DDRG

#define FIFO_EF_PIN PG2
#define FIFO_EF_PORT PORTG
#define FIFO_EF_IN PING
#define FIFO_EF_DDR DDRG

#define FIFO_FF_PIN PG3
#define FIFO_FF_PORT PORTG
#define FIFO_FF_IN PING
#define FIFO_FF_DDR DDRG

#define FIFO_RS_PIN PG4
#define FIFO_RS_PORT PORTG
#define FIFO_RS_IN PING
#define FIFO_RS_DDR DDRG

/* function prototypes */
void FIFO_Write_Init(void);
void FIFO_Reset(void);
unsigned char FIFO_write_byte(unsigned char data_byte);
