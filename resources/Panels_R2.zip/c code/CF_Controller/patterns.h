/*
  Header File for pattern access commands
  By Michael R
*/

/*
Description: Header file for the FAT routines. Defines constants and 
contains prototypes for the FAT routines.
*/

/* Definitions */
#define PATTERN_OFFSET 7	//the number of bytes at which to start reading pattern data - should be 6 ??
#define PATTERN_HEADER_BLOCK 32 //the number of blocks at which to start reading pattern info
#define PATTERN_HEADER_SIZE 10 //the number of bytes in each pattern header

/* FAT Prototypes */
void load_pattern(unsigned char pat_num, unsigned char *pattern_data);
void load_frame(unsigned short frame_num, unsigned short frame_size, unsigned short blocks_per_frame, unsigned long start_block);
void scan_patterns(void);

//void test_CF_load(unsigned long start_address, unsigned long num_bytes);
