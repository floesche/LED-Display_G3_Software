/*
  FAT Filesystem Routines
  By Robert Bailey
	
  Revision History:
  07.27.04  RB  Created
*/

#include "fat.h"
#include "cf.h"
#include "ser128.h"
#include "legacy.h"
#include <avr/io.h>

int data_block[256];
unsigned char sectors_per_cluster;
unsigned char number_of_fats;
int sectors_per_fat;
int reserved_sectors;
long starting_data_sector;
long hidden_sectors;
long fat_lba;
long root_lba;
int current_file_cluster;
int starting_file_cluster;
long current_file_length;
char volume_label[11];
long current_file_pointer;
int byte_offset;

/* returns 0 on success, and non-zero on failure */
unsigned char FAT_Init(void)
{
  unsigned char i;
  int fat_entries;
  long block;
  
  cf_get_block(data_block,PARTITION_SECTOR);   /* get partition table */
  
  /* check the signature */
  if(data_block[SIG_LOCATION]==SECTOR_SIG)
  {
    /* get the LBA of the first partition */
    ((unsigned char*)&block)[0] = ((unsigned char*)&data_block)[PARTITION_START+PARTITION_LBA];
    ((unsigned char*)&block)[1] = ((unsigned char*)&data_block)[PARTITION_START+PARTITION_LBA+1];
    ((unsigned char*)&block)[2] = ((unsigned char*)&data_block)[PARTITION_START+PARTITION_LBA+2];
    ((unsigned char*)&block)[3] = ((unsigned char*)&data_block)[PARTITION_START+PARTITION_LBA+3];
        
    cf_get_block(data_block,block);   /* get boot sector of partition */
    
    /* check the signature */
    if(data_block[SIG_LOCATION]==SECTOR_SIG)
    {
      /* get the filesystem parameters */
      sectors_per_cluster = ((unsigned char*)&data_block)[13];
      ((unsigned char*)&reserved_sectors)[0] = ((unsigned char*)&data_block)[14];
      ((unsigned char*)&reserved_sectors)[1] = ((unsigned char*)&data_block)[15];
      number_of_fats = ((unsigned char*)&data_block)[16];
      ((unsigned char*)&fat_entries)[0] = ((unsigned char*)&data_block)[17];
      ((unsigned char*)&fat_entries)[1] = ((unsigned char*)&data_block)[18];
      ((unsigned char*)&sectors_per_fat)[0] = ((unsigned char*)&data_block)[22];
      ((unsigned char*)&sectors_per_fat)[1] = ((unsigned char*)&data_block)[23];
      ((unsigned char*)&hidden_sectors)[0] = ((unsigned char*)&data_block)[28];
      ((unsigned char*)&hidden_sectors)[1] = ((unsigned char*)&data_block)[29];
      ((unsigned char*)&hidden_sectors)[2] = ((unsigned char*)&data_block)[30];
      ((unsigned char*)&hidden_sectors)[3] = ((unsigned char*)&data_block)[31];
      
      starting_data_sector = (fat_entries*32)/SECTOR_SIZE;
      if((fat_entries*32)%SECTOR_SIZE)
        starting_data_sector++;
      starting_data_sector += root_lba;
      
      /* get Volume Label */
      for(i=0;i<11;i++)
      {
        volume_label[i] = ((unsigned char*)&data_block)[43+i];
      }
      
      /* get the LBA of the FAT */
      fat_lba = block+reserved_sectors+hidden_sectors;
      /* get the LBA of the Root Directory */
      root_lba = fat_lba+(number_of_fats*sectors_per_fat);
      /* figure out where the clusters start */
      starting_data_sector = (fat_entries*32)/SECTOR_SIZE;
      if((fat_entries*32)%SECTOR_SIZE)
        starting_data_sector++;
      starting_data_sector += root_lba;      
    }
    else
    {
      /* error 2 */
      return (2);
    }
  }
  else
  {
    /* error 1 */
    return (1);
  }
  
  return (0);
}

/* returns filesize on success, 0 on failure */
long FAT_load_file(char *filename)
{
  int i;
  int current_dir_entry;
  unsigned char match;
  long block;
  
  /* get the Root Directory */
  cf_get_block(data_block,root_lba);
  block = root_lba;
  
  current_dir_entry=0;
  current_file_length=0;
  current_file_pointer=0;
      
  while(((unsigned char*)&data_block)[current_dir_entry]!=0x00)
  {
    /* make sure it's not deleted, a volume, or a directory */
    if((((unsigned char*)&data_block)[current_dir_entry]!='?')&&
      (!(((unsigned char*)&data_block)[current_dir_entry+11]&0x08))&&
      (!(((unsigned char*)&data_block)[current_dir_entry+11]&0x10)))
    {
      /* check file name */
      match=1;  /* assume match */
      for(i=0;i<11;i++)
      {
        if(((unsigned char*)&data_block)[current_dir_entry+i]!=*(filename+i))
        {
          match=0;
        }
      }
      if(match)
      {
        /* set file length and starting cluster */
        /* get file start cluster */
        ((unsigned char*)&current_file_cluster)[0]=((unsigned char*)&data_block)[current_dir_entry+0x1A];
        ((unsigned char*)&current_file_cluster)[1]=((unsigned char*)&data_block)[current_dir_entry+0x1B];
        starting_file_cluster=current_file_cluster;
        /* get file length */
        ((unsigned char*)&current_file_length)[0]=((unsigned char*)&data_block)[current_dir_entry+0x1C];
        ((unsigned char*)&current_file_length)[1]=((unsigned char*)&data_block)[current_dir_entry+0x1D];
        ((unsigned char*)&current_file_length)[2]=((unsigned char*)&data_block)[current_dir_entry+0x1E];
        ((unsigned char*)&current_file_length)[3]=((unsigned char*)&data_block)[current_dir_entry+0x1F];
      }
    }
    current_dir_entry+=32;
    if(current_dir_entry>=512)
    {
      /* goto next sector */
      current_dir_entry=0;
      block++;
      cf_get_block(data_block,block);
    }
  }
  return (current_file_length);
}

// this function (added by MBR 09/27/04 is used to speed up the fat access
// basically this just does what FAT_get_byte_from_file does, upto computing the 
// actual_cluster value, this is then returned, to be stored in a table
int compute_actual_cluster_index(long byte)
{
  unsigned char cluster_index;
  int actual_cluster;
  int i;
  cluster_index = byte / (SECTOR_SIZE*sectors_per_cluster);
    
  actual_cluster=starting_file_cluster;
  for(i=0;i<cluster_index;i++)
  {
    actual_cluster=FAT_get_next_cluster(actual_cluster);
  }
  return (actual_cluster);
}


// this function (added by MBR 09/27/04 is used to speed up the fat access
// basically this just does the second half of what FAT_get_byte_from_file does, 
// uses the actual_cluster value as an input to reduce the sector accesses.
unsigned char FAT_get_byte_from_file_w_actual_cluster(long byte, int actual_cluster)
{
  unsigned char cluster_index;
  int sector;
  cluster_index = byte / (SECTOR_SIZE*sectors_per_cluster);
  sector = (byte-(SECTOR_SIZE*sectors_per_cluster*cluster_index))/SECTOR_SIZE;
  byte_offset = (byte-(SECTOR_SIZE*sectors_per_cluster*cluster_index))-(SECTOR_SIZE*sector);
  current_file_pointer=byte;
    
  FAT_load_sector(actual_cluster,sector);
  
  return (((unsigned char*)&data_block)[byte_offset]);
}


unsigned char FAT_get_byte_from_file(long byte)
{
  unsigned char cluster_index;
  int actual_cluster;
  int sector;
  int i;
  sbi(PORTE,PORTE6);	//debug - start tic
  cluster_index = byte / (SECTOR_SIZE*sectors_per_cluster);
  sector = (byte-(SECTOR_SIZE*sectors_per_cluster*cluster_index))/SECTOR_SIZE;
  byte_offset = (byte-(SECTOR_SIZE*sectors_per_cluster*cluster_index))-(SECTOR_SIZE*sector);
  current_file_pointer=byte;
    
  actual_cluster=starting_file_cluster;
  for(i=0;i<cluster_index;i++)
  {
    actual_cluster=FAT_get_next_cluster(actual_cluster);
  }
  cbi(PORTE,PORTE6);	//debug - end tic
  
  FAT_load_sector(actual_cluster,sector);
  
  /*((unsigned char*)&data_block)[byte_offset];*/
  
  return (((unsigned char*)&data_block)[byte_offset]);
}

void FAT_load_sector(int cluster,int sector)
{
  long block;
  
  block = starting_data_sector+((cluster-2)*sectors_per_cluster)+sector;
  
  cf_get_block(data_block,block);
}

int FAT_get_next_cluster(int cluster)
{
  int sector;
  int word_offset;
  
  sector=(cluster*2)/SECTOR_SIZE;
  cf_get_block(data_block,(fat_lba+sector));
  
  word_offset=((cluster*2)%SECTOR_SIZE)/2;
  
  return (data_block[word_offset]);
}

unsigned char FAT_get_next_byte_from_file(void)
{
  byte_offset++;
  current_file_pointer++;
  
  if(byte_offset<SECTOR_SIZE)
  {
    return (((unsigned char*)&data_block)[byte_offset]);
  }
  else
  {
    return (FAT_get_byte_from_file(current_file_pointer));
  }
}
