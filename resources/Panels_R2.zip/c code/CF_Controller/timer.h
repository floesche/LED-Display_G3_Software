/*
	Timer Header File
	Robert Bailey
	
	Revision History:
	09.29.02	RB	Created
	simple timing functions added by MBR - 5.20.05
	
*/

#define F_CPU 16000000

extern volatile unsigned long ticks;


void timer_init(void);
void Wait(unsigned int delay);

#define secs(A) ((unsigned int) (A * F_CPU / 2048))
#define msecs(A) ((unsigned int) (A * (F_CPU / 1000) / 2048))


void timer_fine_tic(void);
unsigned short timer_fine_toc(void);

void timer_coarse_tic(void);
unsigned long timer_coarse_toc(void);
