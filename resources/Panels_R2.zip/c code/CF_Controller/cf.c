/*
  Compact Flash Routines
  By Robert Bailey
	
  Revision History:
  07.09.04  RB  Created
*/

#include "cf.h"
#include "legacy.h"
#include <avr/io.h>


/* CF ROUTINES */

void CF_Init(void)
{
  /* reset device */
  sbi(CF_RESET_DDR,CF_RESET_PIN);
  cbi(CF_RESET_PORT,CF_RESET_PIN);
  
  cf_clear_data_port();
  
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);    /* clear address line */
  sbi(CF_ADDR0_DDR,CF_ADDR0_PIN);     /* write */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);    /* clear address line */
  sbi(CF_ADDR1_DDR,CF_ADDR1_PIN);     /* write */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);    /* clear address line */
  sbi(CF_ADDR2_DDR,CF_ADDR2_PIN);     /* write */
  cbi(CF_CS0_PORT,CF_CS0_PIN);        /* clear cs line */
  sbi(CF_CS0_DDR,CF_CS0_PIN);         /* write */
  cbi(CF_CS1_PORT,CF_CS1_PIN);        /* clear cs line */
  sbi(CF_CS1_DDR,CF_CS1_PIN);         /* write */
  
  sbi(CF_IORD_PORT,CF_IORD_PIN);        /* set iorw line */
  sbi(CF_IORD_DDR,CF_IORD_PIN);         /* write */
  sbi(CF_IOWR_PORT,CF_IOWR_PIN);        /* set iowr line */
  sbi(CF_IOWR_DDR,CF_IOWR_PIN);         /* write */
  
  sbi(CF_IORDY_PORT,CF_IORDY_PIN);    /* turn on pull up */
  cbi(CF_IORDY_DDR,CF_IORDY_PIN);     /* read */
  
  /* make device active */
  sbi(CF_RESET_PORT,CF_RESET_PIN);
  
}

/* checks the busy flag. blocking function until device not busy */
void WaitBusy(void)
{
  unsigned int data_in;
  
  /* setup status register address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* active */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  
  do
  {
    data_in = cf_read_word();   /* read status register */
  }while((data_in&0x00C0)!=0x0040); /* device not busy and ready for command */
}

unsigned char cf_read_status(void)
{
  unsigned int data_in;
  
  /* setup status register address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* active */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  
  data_in = cf_read_word();   /* read status register */
  
  return (((unsigned char*)&data_in)[0]);
}

/* reads one word from the compact flash with address already setup before 
    call */
unsigned int cf_read_word(void)
{
  unsigned int data_in;
  
  cf_clear_data_port();
  
  cbi(CF_IORD_PORT,CF_IORD_PIN);  /* assert IORD signal */
  
  nop();
  nop();
  while((inp(CF_IORDY_PORT)&(1<<CF_IORDY_PIN))==0); /* wait for IORDY */
   
  ((unsigned char*)&data_in)[0] = inp(CF_DATA_LOW_IN);  
  ((unsigned char*)&data_in)[1] = inp(CF_DATA_HIGH_IN);
  
  sbi(CF_IORD_PORT,CF_IORD_PIN);  /* clear IORD signal */
  
  cf_clear_data_port();
  
  return (data_in);
}

void cf_write_word(unsigned int data_out)
{
  CF_DATA_HIGH_OUT = ((unsigned char*)&data_out)[1];    /* put data_out on the port */
  CF_DATA_LOW_OUT = ((unsigned char*)&data_out)[0];
  
  CF_DATA_HIGH_DDR = 0xFF;    /* write */
  CF_DATA_LOW_DDR = 0xFF;
  
  cbi(CF_IOWR_PORT,CF_IOWR_PIN);  /* assert IOWR signal */

  nop();
  nop();
  nop();
  nop();
  while((inp(CF_IORDY_PORT)&(1<<CF_IORDY_PIN))==0); /* wait for IORDY */
    
  sbi(CF_IOWR_PORT,CF_IOWR_PIN);  /* clear IOWR signal */
  cf_clear_data_port();
}

void cf_get_block(int *block,unsigned long lba)
{
  int data_out,i;
  
  data_out=0x0000;
  
  /* setup sector count address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* inactive */
  /* write sector count */
  cf_write_word(0x0001);  /* only getting one sector */
  
  /* setup LBA_0 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[0];
  /* write the data */
  cf_write_word(data_out);
  
  /* setup LBA_1 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[1];
  /* write the data */
  cf_write_word(data_out);
  
  /* setup LBA_2 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[2];
  /* write the data */
  cf_write_word(data_out);
  
  /* setup LBA_3 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[3];
  /* write the data */
  cf_write_word((data_out|0x00E0));
  
  /* setup command register address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* active */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* issue the read sector command */
  cf_write_word(0x0020);
  
  WaitBusy();
  
  /* setup data register address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* inactive */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* inactive */
  
  for(i=0;i<256;i++)
  { 
    *(block+i) = cf_read_word();
  } 
}



void cf_get_partial_block(int *block,unsigned long lba, unsigned short num_words)
{
  int data_out,i;
  
  data_out=0x0000;
  
  /* setup sector count address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* inactive */
  /* write sector count */
  cf_write_word(0x0001);  /* only getting one sector */
  
  /* setup LBA_0 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[0];
  /* write the data */
  cf_write_word(data_out);
  
  /* setup LBA_1 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[1];
  /* write the data */
  cf_write_word(data_out);
  
  /* setup LBA_2 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[2];
  /* write the data */
  cf_write_word(data_out);
  
  /* setup LBA_3 address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* setup the data to write */
  ((unsigned char*)&data_out)[0]=((unsigned char*)&lba)[3];
  /* write the data */
  cf_write_word((data_out|0x00E0));
  
  /* setup command register address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  sbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* active */
  sbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* active */
  sbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* active */
  /* issue the read sector command */
  cf_write_word(0x0020);
  
  WaitBusy();
  
  /* setup data register address */
  cbi(CF_CS0_PORT,CF_CS0_PIN);      /* active */
  sbi(CF_CS1_PORT,CF_CS1_PIN);      /* inactive */
  cbi(CF_ADDR0_PORT,CF_ADDR0_PIN);  /* inactive */
  cbi(CF_ADDR1_PORT,CF_ADDR1_PIN);  /* inactive */
  cbi(CF_ADDR2_PORT,CF_ADDR2_PIN);  /* inactive */
  
  for(i=0; i<num_words;i++)
  { 
    *(block+i) = cf_read_word();
  } 
}


void cf_clear_data_port(void)
{
  CF_DATA_HIGH_OUT = 0x00;    /* clear the data port to turn off pullups */
  CF_DATA_LOW_OUT = 0x00;
  
  CF_DATA_HIGH_DDR = 0x00;    /* read */
  CF_DATA_LOW_DDR = 0x00;
}
