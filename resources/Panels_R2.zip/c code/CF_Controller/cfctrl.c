/*
  Compact Flash Controller
*/

#include "cfctrl.h"
#include "ser128.h"
#include "cf.h"
#include "timer.h"
#include "fat.h"
#include "fifo_write.h"
#include "patterns.h"
#include "legacy.h"

#include <avr/io.h>
#include <avr/pgmspace.h>

int main(void)
{ 
  unsigned char Rx_buffer[10];  //make this longer if longer messages will be received
  unsigned char Tx_buffer[10];  //make this longer if longer messages will be sent
  unsigned char pattern_data[PATTERN_HEADER_SIZE];  
  unsigned char message_length;
  u16 frame_size = 0;		//just give these default values
  u16 num_frames = 0;		//just give these default values
  u08 num_panels, gs_value;
  u16 x_num, y_num;
  unsigned long start_block;
  unsigned long bench_time;
  unsigned short frame_rate;
  unsigned short blocks_per_frame = 1;
  unsigned short frame_number;  
  unsigned short m_seconds, u_seconds;  
  
  //outp((1<<PORTD6),DDRD);	//for using port D for debugging  //outp((1<<PORTE6),DDRE);	//for using port E for debugging
  outp((1<<PORTD5),DDRD);	//enable  PD5 as CCON1 as output from CF to main
  cbi(PORTD,PORTD5);   // clear the pat ready bit	
  
  UART_Init(DBG_UART);
  UART_Init(CTL_UART);
  timer_init();
  FIFO_Write_Init();
  CF_Init();
  
  
  // this is stupid (wait - resets counter) but is good enough for test
  UART_Putstr(DBG_UART,PSTR("Testing the timers...."));	
  timer_coarse_tic();
  Wait(msecs(10));
  bench_time = timer_coarse_toc()/2;
  UART_CRLF(DBG_UART);
  UART_Putstr(DBG_UART,PSTR("Total time for 10 ms wait was "));	UART_SendLong(DBG_UART, bench_time);
  
  timer_coarse_tic();
  bench_time = timer_coarse_toc()/2;
  UART_CRLF(DBG_UART);
  UART_Putstr(DBG_UART,PSTR("Total time for 0 ms wait was "));	UART_SendLong(DBG_UART, bench_time);
  
  /* give device time to initialize and wait for it to be ready */
  WaitBusy();
  
  //scan the CF for patters and run quick timing trials
  scan_patterns();
  
  while(1){
  
	if ( bit_get(PIND,BIT(6)) )  //if main ctrl got the frame from the fifo, then
		cbi(PORTD,PORTD5);   // clear the pat ready bit
  
	if (UART_CharReady(CTL_UART))
	{
		message_length = fill_Rx_buffer(CTL_UART,&Rx_buffer[0]);
			
		switch(message_length) 
		{			
			case 1: 
			//this is start benchmark case
			if (Rx_buffer[0] == 0xF0){
				Tx_buffer[0] = 0x00;  	//send 0x00 to other ctl to indicate message received
				send_Tx_buffer(CTL_UART, &Tx_buffer[0], 1);	
				timer_coarse_tic();			
			}
			else {
				if (Rx_buffer[0] == 0x0F){ //stop benchmark
					bench_time = timer_coarse_toc()/2;
					
					UART_CRLF(DBG_UART);
					UART_Putstr(DBG_UART,PSTR("Total time for all frames was "));	UART_SendLong(DBG_UART, bench_time);
					UART_Putstr(DBG_UART,PSTR(" us. This patterns has "));	
					
					UART_SendShort(DBG_UART, num_frames); UART_Putstr(DBG_UART,PSTR(" frames,"));
					UART_CRLF(DBG_UART); UART_Putstr(DBG_UART,PSTR(" so average frame display time is "));	
					
					if (bench_time > 65500*num_frames) {
						m_seconds = ((bench_time/1000)/num_frames);
						UART_SendShort(DBG_UART, m_seconds);
						UART_Putstr(DBG_UART,PSTR(" ms. So approx. frame rate is "));							
					}
					else {
						u_seconds = ((bench_time)/num_frames);
						UART_SendShort(DBG_UART, u_seconds);
						UART_Putstr(DBG_UART,PSTR(" us. So approx. frame rate is "));							
					}						
					
					frame_rate = ((unsigned long)(1000000*num_frames))/bench_time;
					UART_SendShort(DBG_UART, frame_rate);
					UART_Putstr(DBG_UART,PSTR(" Hz."));						
				}
				else{
					UART_CRLF(DBG_UART);
					UART_Putstr(DBG_UART,PSTR("ERROR! message mixup for length 1 message, can't decode!"));
				}
			}
			
			break;
			case 2:  	//this is the load pattern case
				if (Rx_buffer[0]  == 0x00) {
					//Rx_buffer[1] should contain the pattern ID, so use this to open the file
					load_pattern(Rx_buffer[1], &pattern_data[0]);
					
					((unsigned char*)&x_num)[0] = pattern_data[0];
					((unsigned char*)&x_num)[1] = pattern_data[1];
					((unsigned char*)&y_num)[0] = pattern_data[2];
					((unsigned char*)&y_num)[1] = pattern_data[3];
					num_frames = x_num*y_num;	  
					num_panels = pattern_data[4];
					gs_value = pattern_data[5];
					
					if ((gs_value >= 11) & (gs_value <= 13))
						{frame_size = num_panels*(gs_value - 10);}
					else	
						{frame_size = num_panels*gs_value*8;}
					//blocks_per_frame = 1;
					//compute this better later - while loop add up, maybe
					blocks_per_frame = frame_size/512 + 1;
					UART_CRLF(DBG_UART);
					UART_Putstr(DBG_UART,PSTR("number of blocks per frame: "));
					UART_SendShort(DBG_UART, blocks_per_frame);
	
					((unsigned char*)&start_block)[0] = pattern_data[6];
					((unsigned char*)&start_block)[1] = pattern_data[7];
					((unsigned char*)&start_block)[2] = pattern_data[8];
					((unsigned char*)&start_block)[3] = pattern_data[9];  
					
					send_Tx_buffer(CTL_UART, &pattern_data[0], 6); // just send the pattern data buffer
					
					UART_CRLF(DBG_UART);
					UART_Putstr(DBG_UART,PSTR("Pattern loaded, with frame size: "));
					UART_SendShort(DBG_UART, frame_size);
					if (frame_size == 0) //error either loading file or with file content
					{
						UART_CRLF(DBG_UART);
						UART_Putstr(DBG_UART,PSTR("ERROR! File did not load"));
						Tx_buffer[0] = 0x01;  	//send 0x01 to other ctl to indicate data load error
						send_Tx_buffer(CTL_UART, &Tx_buffer[0], 1);			
					}
				FIFO_Reset();
				}	
				else {
					UART_CRLF(DBG_UART);
					UART_Putstr(DBG_UART,PSTR("ERROR! message mixup for length 2 message, can't decode!"));
				}
			break;
				
			case 3:			//this is the load frame case
				if (Rx_buffer[0]  == 0x00) {
					
					((unsigned char*)&frame_number)[0] = Rx_buffer[1];
					((unsigned char*)&frame_number)[1] = Rx_buffer[2];
					load_frame(frame_number, frame_size, blocks_per_frame, start_block);
					//cbi(PORTD,PORTD6);	//debug - exit the load frame 
					
					//UART_CRLF(DBG_UART);
					//UART_Putstr(DBG_UART,PSTR("Frame loaded, frame number: "));
					//UART_SendShort(DBG_UART, frame_number); 
							
					//CF_ctl -> TWI_ctl sends 0x00 if not error, otherwise sends error codes
					//0x01 - frame_number out of range, 0x02 - pattern_ID not set 
					
					//set CCON1 to HI as signal.
					bit_set(PORTD, BIT(5));   // in place of - sbi(PORTD,PORTD5);
					//Tx_buffer[0] = 0x00;  	//send 0x00 to other ctl to indicate all data dumped - 
					//send_Tx_buffer(CTL_UART, &Tx_buffer[0], 1);			//change this to intermediate message latter
				}	
				else {
					UART_CRLF(DBG_UART);
					UART_Putstr(DBG_UART,PSTR("ERROR! message mixup for length 3 message, can't decode!"));
				}
			break;
					
			default:
				UART_CRLF(DBG_UART);
				UART_Putstr(DBG_UART,PSTR("ERROR! message_length is irregular, can't decode!"));
						
				}
			}
	}
	return(0);
}	  