/*
  FAT Filesystem Routines Header File
  By Robert Bailey
*/

/*
Description: Header file for the FAT routines. Defines constants and 
contains prototypes for the FAT routines.
*/

/* FAT Definitions */
#define PARTITION_SECTOR 0
#define SECTOR_SIG 0xAA55
#define SIG_LOCATION 255
#define PARTITION_START 512-66
#define PARTITION_LBA 8
#define SECTOR_SIZE 512

/* FAT Prototypes */
unsigned char FAT_Init(void);
long FAT_load_file(char *filename);
unsigned char FAT_get_byte_from_file(long byte);
void FAT_load_sector(int cluster,int sector);
int FAT_get_next_cluster(int cluster);
unsigned char FAT_get_next_byte_from_file(void);
//added by MBR to speed up FAT access - 
int compute_actual_cluster_index(long byte);
unsigned char FAT_get_byte_from_file_w_actual_cluster(long byte, int actual_cluster);

