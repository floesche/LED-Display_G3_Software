/*
  FIFO Write Routines
  By Robert Bailey
	
  Revision History:
  07.29.04  RB  Created
*/

#include "fifo_write.h"
#include "legacy.h"

#include <avr/io.h>

void FIFO_Write_Init(void)
{
  FIFO_DATA_PORT=0x00;    /* clear the data port */
  FIFO_DATA_DDR=0xFF;     /* and set to write */
  
  cbi(FIFO_RS_PORT,FIFO_RS_PIN);          /* reset device */
  sbi(FIFO_RS_DDR,FIFO_RS_PIN);           /* write */
  
  cbi(FIFO_WCLK_PORT,FIFO_WCLK_PIN);      /* clear wclk */
  sbi(FIFO_WCLK_DDR,FIFO_WCLK_PIN);       /* write */
  
  sbi(FIFO_WEN1_PORT,FIFO_WEN1_PIN);      /* clear wen1 */
  sbi(FIFO_WEN1_DDR,FIFO_WEN1_PIN);       /* write */
  
  cbi(FIFO_WEN2_PORT,FIFO_WEN2_PIN);      /* clear wen2 */
  sbi(FIFO_WEN2_DDR,FIFO_WEN2_PIN);       /* write */
  
  cbi(FIFO_PAF_PORT,FIFO_PAF_PIN);        /* turn off pullup */
  cbi(FIFO_PAF_DDR,FIFO_PAF_PIN);         /* read */
  
  cbi(FIFO_PAE_PORT,FIFO_PAE_PIN);        /* turn off pullup */
  cbi(FIFO_PAE_DDR,FIFO_PAE_PIN);         /* read */
  
  cbi(FIFO_EF_PORT,FIFO_EF_PIN);          /* turn off pullup */
  cbi(FIFO_EF_DDR,FIFO_EF_PIN);           /* read */
  
  cbi(FIFO_FF_PORT,FIFO_FF_PIN);          /* turn off pullup */
  cbi(FIFO_FF_DDR,FIFO_FF_PIN);           /* read */
  
  FIFO_Reset();
}

void FIFO_Reset(void)
{
  sbi(FIFO_WEN2_PORT,FIFO_WEN2_PIN);      /* set wen2 */
  cbi(FIFO_RS_PORT,FIFO_RS_PIN);          /* reset device */
  sbi(FIFO_RS_PORT,FIFO_RS_PIN);          /* activate device */
  cbi(FIFO_WEN2_PORT,FIFO_WEN2_PIN);      /* clear wen2 */
}

/* returns 0 on success, 1 on failure */
unsigned char FIFO_write_byte(unsigned char data_byte)
{
  FIFO_DATA_PORT = data_byte;
  
  if((inp(FIFO_FF_IN)&(1<<FIFO_FF_PIN)))
  {
    cbi(FIFO_WEN1_PORT,FIFO_WEN1_PIN);      /* set wen1 */
    sbi(FIFO_WEN2_PORT,FIFO_WEN2_PIN);      /* set wen2 */
    
    /* pulse write clock */
    sbi(FIFO_WCLK_PORT,FIFO_WCLK_PIN);      /* set wclk */
    cbi(FIFO_WCLK_PORT,FIFO_WCLK_PIN);      /* clear wclk */
    
    sbi(FIFO_WEN1_PORT,FIFO_WEN1_PIN);      /* clear wen1 */
    cbi(FIFO_WEN2_PORT,FIFO_WEN2_PIN);      /* clear wen2 */
  }
  else
  {
    return (1);   /* error */
  }
  return (0);
}
