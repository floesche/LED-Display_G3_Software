/*
  Pattern Access routines
  By Michael Reiser
	
  Revision History:
  09.29.04  MR  Created
*/

#include "patterns.h"
#include "cf.h"
#include "timer.h"
#include "fifo_write.h"
#include <avr/io.h>
//these are just for debugging, remove later
#include "ser128.h"
#include <avr/pgmspace.h>
#define DBG_UART 0

/* PATTERN ROUTINES */
void load_pattern(unsigned char pat_num, unsigned char *pattern_data)
{
	int data_block[256];
	int pattern_info_start_address;
	unsigned char j;
	
	cf_get_block(data_block, PATTERN_HEADER_BLOCK);   /* get pattern_table */
	//compute the address of the pattern_info
	//subtract 1 from pat_num, because there is no pattern 0.
	pattern_info_start_address = (pat_num - 1)*PATTERN_HEADER_SIZE;
	
	for (j = 0; j < PATTERN_HEADER_SIZE; j++)
	{
		pattern_data[j] = (((unsigned char*)&data_block)[pattern_info_start_address + j]);
	}	
}


void load_frame(unsigned short frame_num, unsigned short frame_size, unsigned short blocks_per_frame, unsigned long start_block)
{
	int data_block[256];
	unsigned long frame_start_block;
	unsigned char j;
	unsigned short i;
	unsigned short num_frames_to_FIFO;
	
	//compute the block of the starting frame;
	frame_start_block = start_block + frame_num*blocks_per_frame; // there is a frame zero (?)
	//handle all complete (512) byte blocks in this loop
	for (j = 0; j < (blocks_per_frame - 1); j++)
	{
		cf_get_block(data_block, frame_start_block + j);   /* get j_th block of the frame */
		for (i = 0; i < 512; i++)
		{
			//UART_SendNum(DBG_UART,  ((unsigned char*)&data_block)[i]);
			//UART_Putstr(DBG_UART,PSTR(" ")); 
			while(FIFO_write_byte( (((unsigned char*)&data_block)[i]) ) );
		}	    
	}
	//now handle the last, partial block
	//cf_get_block(data_block, (frame_start_block + blocks_per_frame - 1));   // still have to grab the whole block - maybe not????
	num_frames_to_FIFO = frame_size % 512;
	// try to grab partial block - use numframes/2 + 1 as safe number of words to grab.
	cf_get_partial_block(data_block, (frame_start_block + blocks_per_frame - 1), (num_frames_to_FIFO >> 1) + 1);   
	//instead of all this math above, just add j?
	
	for (i = 0; i < num_frames_to_FIFO; i++)
	{
		//UART_SendNum(DBG_UART,  ((unsigned char*)&data_block)[i]); 
		//UART_Putstr(DBG_UART,PSTR(" ")); 
		while(FIFO_write_byte( (((unsigned char*)&data_block)[i]) ) );
	}	    
	
}

void scan_patterns(void)
{
	int data_block[256];
	int pattern_info_start_address;
	unsigned char pattern_data[PATTERN_HEADER_SIZE];  
	unsigned char pattern_index = 1;
	unsigned char j;
	unsigned char keep_going = 1;
	unsigned short frame_size = 0;		//just give these default values
	unsigned short num_frames = 0;		//just give these default values
	unsigned char num_panels, gs_value;
	unsigned short x_num, y_num;
	unsigned short blocks_per_frame = 1;
	unsigned long start_block;
	unsigned short min_time;
	unsigned short del_t;
	unsigned short min_t = 6500; //set to something large
	unsigned short max_t = 0;
	unsigned long total_time = 0;
	unsigned short avg_time = 0;
	

	timer_fine_tic();
	min_time = timer_fine_toc();
	
	for (j = 0; j < 100; j++)
	{	
		timer_fine_tic();
		cf_get_block(data_block, PATTERN_HEADER_BLOCK + j*10);
		del_t = (timer_fine_toc() - min_time)/2;
		if (del_t > max_t) {max_t = del_t;}
		if (del_t < min_t) {min_t = del_t;}
		total_time = total_time + del_t;		
	}	
		
	avg_time = total_time/100;
		
	UART_CRLF(DBG_UART);
	UART_Putstr(DBG_UART,PSTR("Average time per CF block: "));	UART_SendShort(DBG_UART, avg_time);
	UART_Putstr(DBG_UART,PSTR(" us. Min time: ")); UART_SendShort(DBG_UART, min_t);
	UART_Putstr(DBG_UART,PSTR(" us. Max time: "));	UART_SendShort(DBG_UART, max_t);
	UART_Putstr(DBG_UART,PSTR(" us."));
		
		
	cf_get_block(data_block, PATTERN_HEADER_BLOCK);   /* get pattern_table */
	//compute the address of the pattern_info
	//subtract 1 from pat_num, because there is no pattern 0
		
	UART_CRLF(DBG_UART); UART_Putstr(DBG_UART,PSTR("Scanning the CF card for patterns....."));
		
	while (keep_going)
	{	
		pattern_info_start_address = (pattern_index - 1)*PATTERN_HEADER_SIZE;
	
		for (j = 0; j < PATTERN_HEADER_SIZE; j++)
		{
			pattern_data[j] = (((unsigned char*)&data_block)[pattern_info_start_address + j]);
		}	
		
		((unsigned char*)&x_num)[0] = pattern_data[0];
		((unsigned char*)&x_num)[1] = pattern_data[1];
		((unsigned char*)&y_num)[0] = pattern_data[2];
		((unsigned char*)&y_num)[1] = pattern_data[3];
		((unsigned char*)&start_block)[0] = pattern_data[6];
		((unsigned char*)&start_block)[1] = pattern_data[7];
		((unsigned char*)&start_block)[2] = pattern_data[8];
		((unsigned char*)&start_block)[3] = pattern_data[9];  

		num_frames = x_num*y_num;	  
		num_panels = pattern_data[4];
		gs_value = pattern_data[5];
		if ((gs_value >= 11) & (gs_value <= 13))
			{frame_size = num_panels*(gs_value - 10);}
		else	
			{frame_size = num_panels*gs_value*8;}
		//frame_size = num_panels*gs_value*8;
		//blocks_per_frame = 1;
		blocks_per_frame = frame_size/512 + 1;
		
		if (frame_size > 0)
		{
			UART_CRLF(DBG_UART); UART_Putstr(DBG_UART,PSTR("Pattern "));
			UART_SendNum(DBG_UART, pattern_index);	
			UART_Putstr(DBG_UART,PSTR(": x_num = ")); UART_SendShort(DBG_UART, x_num);	
			UART_Putstr(DBG_UART,PSTR(", y_num = ")); UART_SendShort(DBG_UART, y_num);	
			UART_Putstr(DBG_UART,PSTR(", num_frames = ")); UART_SendShort(DBG_UART, num_frames);	
			UART_Putstr(DBG_UART,PSTR(",gs_value = ")); UART_SendNum(DBG_UART, gs_value);
			UART_CRLF(DBG_UART);
			UART_Putstr(DBG_UART,PSTR("             num_panels = ")); UART_SendNum(DBG_UART, num_panels);	
			UART_Putstr(DBG_UART,PSTR(", frame_size = ")); UART_SendShort(DBG_UART, frame_size);
			
			timer_fine_tic();
			load_frame(1, frame_size, blocks_per_frame, start_block);
			del_t = (timer_fine_toc() - min_time)/2;
			
			UART_Putstr(DBG_UART,PSTR(". Time (us) per frame: "));
			UART_SendShort(DBG_UART, del_t);
			
			pattern_index = pattern_index + 1;
		}
		else
		{
			keep_going = 0;
			UART_CRLF(DBG_UART);
			UART_SendNum(DBG_UART, pattern_index - 1);
			UART_Putstr(DBG_UART,PSTR(" total patterns on the CF.")); 	
		}
	}
	
}