%make panel ring layout
%script Panel_ring_layout.m
clear
num_panels = 20
panel_width = 1.26;
panel_depth = 0.31;
pin_dist = 0.6; %pin_dist = 0.62;
pin_width = 0.7;

%pan_chord = sqrt((panel_width/2)^2 + (panel_depth/2)^2)

alpha = 2*pi/num_panels;   %angle subtended by one panel from center
c_radius = panel_width/(tan(alpha/2))/2

alphas = 0:alpha:2*pi-0.01;
P_angle = alphas + pi/2

figure; hold on

for j = 1:num_panels
    P_center = [c_radius*cos(alphas(j)), c_radius*sin(alphas(j))];
    V(1,:) = [P_center(1) - panel_width/2*cos(P_angle(j)),  P_center(2) - panel_width/2*sin(P_angle(j))];
    V(2,:) = [P_center(1) + panel_width/2*cos(P_angle(j)),  P_center(2) + panel_width/2*sin(P_angle(j))];
    plot(V(:,1), V(:,2))
end

for j = 1:num_panels
    P_center = [(c_radius+pin_dist)*cos(alphas(j)), (c_radius+pin_dist)*sin(alphas(j))];
    P(1,:,j) = [P_center(1) - pin_width/2*cos(P_angle(j)),  P_center(2) - pin_width/2*sin(P_angle(j))];         
    for i = 2:8
        P(i,:,j) = [P(i-1,1,j) + 0.1*cos(P_angle(j)),  P(i-1,2,j) + 0.1*sin(P_angle(j))];       
    end
    plot(P(:,1,j), P(:,2,j), 'ok' )
end

axis equal
