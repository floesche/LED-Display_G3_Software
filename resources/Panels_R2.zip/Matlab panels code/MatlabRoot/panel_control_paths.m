% set PControl paths
function_path = 'c:\matlabroot\Panels\functions';
pattern_path =  'c:\matlabroot\Panels\patterns';
temp_path = 'c:\matlabroot\temp';
root_path = 'c:\matlabroot\';
controller_path = 'c:\matlabroot\Panels\controller';