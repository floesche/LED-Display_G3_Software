%panel_strip_layout.m

%make panel strip layout

clear
num_panels = 8;
% these are the depth and width of the LED module in inches
panel_width = 1.27; %panel_width = 1.26;
panel_depth = 0.31; % value currently not used
panel_offset = 0.2;

% pin_dist is the distance from the front (light emmitting surface) of the
% panel to the row of pins. This is approx 0.6 for old panels (0.62 to give
% a bit of extra room) and 0.3 for new panels.
pin_dist = 0.33;
pin_width = 0.7; % width of the 8 pins (0.1 spacing)

figure; hold on

for j = 1:num_panels
    P_center = [panel_offset, (panel_width/2 + panel_width*(j-1))];
    V(1,:) = [panel_offset,  P_center(2) - panel_width/2];
    V(2,:) = [panel_offset,  P_center(2) + panel_width/2];
    plot(V(:,1), V(:,2))
end

for j = 1:num_panels
    P_center = [panel_offset - pin_dist, (panel_width/2 + panel_width*(j-1)) ];
    P(1,:,j) = [P_center(1),  P_center(2) - pin_width/2];         
    for i = 2:8
        P(i,:,j) = [P(i-1,1,j),  P(i-1,2,j) + 0.1];       
    end
    plot(P(:,1,j), P(:,2,j), 'ok' )
end

axis equal
