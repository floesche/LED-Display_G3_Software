function send_function(channel)

panel_control_paths; % run to get path for functions.
cd(function_path);
[FileName,PathName] = uigetfile('function*.mat','Select a Function File');
if ((length(FileName) > 1)&(length(PathName) > 1))
    load([PathName FileName]);

    % for panel patterns, must be 50 Hz, 20 seconds in length
    time = 1/50:(1/50):20;
    scaled_func = round(20.*func);   % 20 = 1V
    figure(4);
    subplot(211)
    plot(time, scaled_func);
    title('20 seconds of the function')
    xlabel('time')
    ylabel('20 * volts')
    subplot(212)
    zoom_time = [time(end-19:end) time(end)+time(1:20)];
    zoom_func = [scaled_func(end-19:end) scaled_func(1:20)];
    plot(zoom_time, zoom_func);
    hold on
    plot([20 20], [min(zoom_func) max(zoom_func)], 'r')
    axis tight
    xlabel('Make sure the function is periodic-left click to accept, right click to cancel')
    [a,b,button] = ginput(1);
    if (button == 1)
        if (lower(channel) == 'x')
            func_channel = 1;
        elseif (lower(channel) == 'y')
            func_channel = 2;
        else
            error('the channel argument must be x or y only');
        end


        for j = 0:19
            start_addr = 1 + j*50;
            end_addr = start_addr + 49;
            Panel_com('send_function', [func_channel j scaled_func(start_addr:end_addr)]);
            pause(0.2);
        end
    end

    close(4)
end