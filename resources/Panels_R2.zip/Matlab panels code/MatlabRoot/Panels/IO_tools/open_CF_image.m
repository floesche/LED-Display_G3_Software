function CF_image = open_CF_image()

panel_control_paths;
fid = fopen([temp_path '\cf.img'] , 'r');
CF_image = fread(fid, inf, 'uchar');
fclose('all');
