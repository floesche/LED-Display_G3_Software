function CF = make_flash_image(file_list)
% this is the gui-friendly version of the file prepare_flash_image
%% file_list is a structure with fields FileName and PathName

block_size = 512; % all data must be in units of block size
Header_size = 10; % number of bytes in the header block
num_blocks_needed = 0; %initialize to zero
block_offset = 32;  % offset to start of pattern data

num_patterns = length(file_list);

Header_block = zeros(1, block_size);

%% first pass gets all the information for the header, and determined how
%% much space is needed for the image - this is done to speed things up by
%% pre-allocating space.
CF.num_patterns = num_patterns;
for j = 1:num_patterns
    load([file_list(j).PathName '\' file_list(j).FileName]);
    
    % determine if row_compression is on  
    row_compression(j) = 0;
    if isfield(pattern, 'row_compression') % for backward compatibility
        if (pattern.row_compression)
            row_compression(j) = 1;
        end
    end
   
    if (row_compression(j))
        current_frame_size(j) = pattern.num_panels*pattern.gs_val;
    else
        current_frame_size(j) = pattern.num_panels*pattern.gs_val*8;
    end
    
    blocks_per_frame(j) = ceil(current_frame_size(j)/block_size);
    current_num_frames(j) = pattern.x_num*pattern.y_num;
    num_blocks_needed = num_blocks_needed + blocks_per_frame(j)*current_num_frames(j);
    Header_start_pos = (j-1)*Header_size + 1;
    if (row_compression(j)) % hack - append 10 to gs_val to let controller know that it is a row_compressed pattern w/o adding more to header block
        Header_block(Header_start_pos:Header_start_pos+5) = [dec2char(pattern.x_num,2), dec2char(pattern.y_num,2), pattern.num_panels, 10 + pattern.gs_val];
    else
        Header_block(Header_start_pos:Header_start_pos+5) = [dec2char(pattern.x_num,2), dec2char(pattern.y_num,2), pattern.num_panels, pattern.gs_val];
    end
    % set up CF structure with pattern info
    CF.x_num(j) = pattern.x_num;
    CF.y_num(j) = pattern.y_num;
    CF.num_panels(j) = pattern.num_panels;
    CF.gs_val(j) = pattern.gs_val; % unclear if we should change this to reflect 11, 12, 13 hack
end

current_frame_size
num_blocks_needed

Pattern_Data = zeros(1, num_blocks_needed*block_size);
block_indexer = 1;  % points to the first block
for j = 1:num_patterns
    load([file_list(j).PathName '\' file_list(j).FileName]);

    % now update the header information
    block_start_address = block_offset + block_indexer;
    Header_start_pos = (j-1)*Header_size + 7;
    Header_block(Header_start_pos:Header_start_pos+3) = dec2char(block_start_address,4);
    
    % now write all of the frame info
    for i = 1:current_num_frames(j)
        if (mod(i,1000) == 0)
            i
        end
        cf_start_address = (block_indexer - 1)*block_size + 1;
        cf_end_address = cf_start_address + current_frame_size(j) - 1;    
        % always forced to start frame at a block boundary
        pat_start_address = (i - 1)*current_frame_size(j) + 1;
        pat_end_address = pat_start_address + current_frame_size(j) - 1;    
        Pattern_Data(cf_start_address:cf_end_address) = pattern.data(pat_start_address:pat_end_address);
        block_indexer = block_indexer + blocks_per_frame(j);
    end    
end

Data_to_write = [Header_block Pattern_Data];
panel_control_paths;

fid = fopen([temp_path '\cf.img'] , 'w');
fwrite(fid, Data_to_write(:),'uchar');
fclose('all');
display([num2str(num_patterns) ' patterns written to temporary file c:\matlabroot\temp\cf.img, of size ' num2str(size(Data_to_write,2)) ' bytes']);