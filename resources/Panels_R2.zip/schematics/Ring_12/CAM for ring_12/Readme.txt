LED Panel Ring Base 12 Readme File

*File List*
drill.txt		- Drill File for board
ring12.apr		- aperture file
ring12.GBL		- Bottom Layer Copper Gerber
ring12.GBS		- Bottom Soldermask Gerber
ring12.GTL		- Top Layer Copper Gerber
ring12.GTS		- Top Soldermask Gerber
ring12.GM1		- Physical Outline of Board
ring12.GTO		- Silkscreen Gerber
ring12.GD1		- Drill Drawing Gerber
ring12.GG1		- Drill Guide Gerber

Board Dimensions
x=6800mil
y=6800mil