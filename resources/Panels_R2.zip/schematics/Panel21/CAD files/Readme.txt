LED Panel v2.1 Readme File

*File List*
drill.txt		- Drill File for board
panel21.apr		- aperture file
panel21.GBL		- Bottom Layer Copper Gerber
panel21.GBS		- Bottom Soldermask Gerber
panel21.GTL		- Top Layer Copper Gerber
panel21.GTS		- Top Soldermask Gerber
panel21.GM1		- Physical Outline of Board
panel21.GM4		- Silkscreen Gerber
panel21.GD1		- Drill Drawing Gerber
panel21.GG1		- Drill Guide Gerber

Dimensions
X: 1260mil
Y: 1260mil