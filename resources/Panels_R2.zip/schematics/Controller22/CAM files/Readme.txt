LED Controller v2.2 Readme File

*File List*
drill.txt		- Drill File for board
ledctrl2.apr		- aperture file
ledctrl2.GBL		- Bottom Layer Copper Gerber
ledctrl2.GBS		- Bottom Soldermask Gerber
ledctrl2.GTL		- Top Layer Copper Gerber
ledctrl2.GTS		- Top Soldermask Gerber
ledctrl2.GM1		- Physical Outline of Board
ledctrl2.GTO		- Silkscreen Gerber
ledctrl2.GD1		- Drill Drawing Gerber
ledctrl2.GG1		- Drill Guide Gerber

Board Dimensions
x=8320mil
y=6960mil